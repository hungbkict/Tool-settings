package model;
import lombok.Data;

@Data
public class Client {
    private String clientId;
    private String clientSecret;

    public Client(String clientId, String clientSecret){
        this.clientId = clientId;
        this.clientSecret =clientSecret;
    }
}