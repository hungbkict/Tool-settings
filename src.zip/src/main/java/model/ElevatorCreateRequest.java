package model;
import lombok.Data;

@Data
public class ElevatorCreateRequest {
    private String deviceId;
    private String deviceType;
    private String personId;
    private Integer fromBlock;
    private Integer fromFloor;
    private Integer toBlock;
    private Integer toFloor;

    public ElevatorCreateRequest(String deviceId, String deviceType, String personId, Integer fromBlock, Integer fromFloor, Integer toBlock, Integer toFloor){
        this.deviceId = deviceId;
        this.deviceType = deviceType;
        this.personId = personId;
        this.fromBlock = fromBlock;
        this.fromFloor = fromFloor;
        this.toBlock = toBlock;
        this.toFloor = toFloor;
    }
}
