package release2_2_2.ac;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class deleteUserFingerTest {
    public String uid = "41b0bb47-1537-46ec-a3c3-80d66b476f38";
    public String _url = Constants.URL_AC + String.format("/user-fingerprints/user/%s", uid);
    public String _method = Constants.METHOD_DELETE;
    public String _token = Constants.TOKEN_ROOT;
    Map<String, Object> map_params = new HashMap<>();


    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
//                {Constants.METHOD_DELETE},
        };
    }


    @Test(enabled=true)
    public void allValid() {
        Response res = Request.send(_url, _method, _token
                , "", Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

    @Test(enabled=true)
    public void unAuthorized() {
        Response res = Request.send(_url, _method, Constants.TOKEN_OFFICE_MANAGER
                , "", Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Response res = Request.send(_url, met, _token
                , "", Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(405);
    }
}
