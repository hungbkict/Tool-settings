package release2_2_2.ac;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class getUserAccessCodeTest {

    public String _url = Constants.URL_AC + "/users/access-code/000291";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";

    @DataProvider(name="ac_code")
    public Object[][] acCodes(){
        return new Object[][] {
                {"00152"},
                {"   001521   "},
                {"-100"},
                {"-âvvad"},
                {""}
        };
    }

    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
//                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }


    @Test
    public void allValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

    @Test
    public void unAuthorized() throws JsonProcessingException {
        Response res = Request.send(_url, _method, Constants.TOKEN_OFFICE_MANAGER
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code", "data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

    @Test(dataProvider = "ac_code")
    public void getInvalidAcCOde(String code) {
        String urlx = Constants.URL_AC + "/users/access-code/" + code;
        Response res = Request.send(urlx, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        String urlx = Constants.URL_AC + "/users/access-code/000291";
        Response res = Request.send(urlx, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(405);
    }
}
