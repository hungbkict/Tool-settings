package release2_2_2.ac;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class getUserCardByNumberTest {
    public String _url = Constants.URL_AC + "/user-cards/card-number/2353136458";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;



    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
//                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , "", Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Response res = Request.send(_url, met, _token
                , "", Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(405);
    }
}
