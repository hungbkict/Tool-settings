package release2_2_2.guest_reg;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

public class putUpdateGuestRegistrationTest {
    public String _regID = "65aa543e-a347-4f23-837b-aabd1c460767";
    public String _url = Constants.URL_GUEST + String.format("/registrations/%s", _regID);
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"repeatType\": \"ONCE\",\n" +
            "  \"areaId\": 19,\n" +
            "  \"blockId\": 10001,\n" +
            "  \"floorId\": 100040,\n" +
            "  \"companyId\": \"e0f62d48-e14a-4f50-8a0e-c8f66aa05e4f\",\n" +
            "  \"startDate\": \"2021-10-14\",\n" +
            "  \"endDate\": \"2021-10-14\",\n" +
            "  \"guests\": [\n" +
            "    {\n" +
            "      \"createdAt\": 1634207743491,\n" +
            "      \"updatedAt\": 1634207743491,\n" +
            "      \"createdBy\": \"7c01b454-0244-4726-83ed-6c96697dd21a\",\n" +
            "      \"updatedBy\": \"7c01b454-0244-4726-83ed-6c96697dd21a\",\n" +
            "      \"id\": \"6e410710-6993-4299-ba64-02abdc1de14d\",\n" +
            "      \"registrationId\": \"13d15062-785e-450d-836e-81cd2931ed8f\",\n" +
            "      \"guestId\": \"6e410710-6993-4299-ba64-02abdc1de14d\",\n" +
            "      \"fullName\": \"A\",\n" +
            "      \"phoneNumber\": \"03982016512\",\n" +
            "      \"identityNumber\": \"085612611\",\n" +
            "      \"isRepresentation\": true,\n" +
            "      \"deleted\": false,\n" +
            "      \"accessCode\": \"001592\",\n" +
            "      \"authenticationModes\": [],\n" +
            "      \"authenticationStatus\": \"UNIDENTIFIED\"\n" +
            "    }\n" +
            "  ],\n" +
            "  \"startTimeInMinute\": 1065,\n" +
            "  \"endTimeInMinute\": 1095\n" +
            "}";

    @Test
    public void putUpdateUserInfoValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }
}
