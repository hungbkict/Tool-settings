package release2_2_2.guest_reg;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import libraries.helper.LogsHelper;
import libraries.helper.TextHelper;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class postGuestRegistrationTest {
    public String _url = Constants.URL_GUEST + "/registrations";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"repeatType\": \"ONCE\",\n" +
            "  \"areaId\": 19,\n" +
            "  \"blockId\": 10001,\n" +
            "  \"floorId\": 100040,\n" +
            "  \"companyId\": \"bb97c369-2826-4249-8cd2-b08040fc4739\",\n" +
            "  \"startDate\": \"2021-12-02\",\n" +
            "  \"endDate\": \"2021-12-14\",\n" +
            "  \"guests\": [\n" +
            "    {\n" +
            "      \"fullName\": \""+ TextHelper.randomName() +" Test\",\n" +
            "      \"phoneNumber\": \""+ TextHelper.randomPhoneNumber() +"\",\n" +
            "      \"identityNumber\": \""+ TextHelper.randomIdentityNumber() +"\",\n" +
            "      \"isRepresentation\": true\n" +
            "    }\n" +
            "  ],\n" +
            "  \"startTimeInMinute\": 105,\n" +
            "  \"endTimeInMinute\": 1195\n" +
            "}";
    @Test
    public void allValid() throws IOException {
        for (int i = 0; i < 1; i++) {
            json_input_valid = "{\n" +
                    "  \"repeatType\": \"ONCE\",\n" +
                    "  \"areaId\": 19,\n" +
                    "  \"blockId\": 10002,\n" +
                    "  \"floorId\": 100046,\n" +
                    "  \"companyId\": \"bb97c369-2826-4249-8cd2-b08040fc4739\",\n" +
                    "  \"startDate\": \"2021-12-04\",\n" +
                    "  \"endDate\": \"2021-12-04\",\n" +
                    "  \"guests\": [\n" +
                    "    {\n" +
                    "      \"fullName\": \""+ TextHelper.randomName() +" Test\",\n" +
                    "      \"phoneNumber\": \""+ TextHelper.randomPhoneNumber() +"\",\n" +
                    "      \"identityNumber\": \""+ TextHelper.randomIdentityNumber() +"\",\n" +
                    "      \"isRepresentation\": true\n" +
                    "    }\n" +
                    "  ],\n" +
                    "  \"startTimeInMinute\": 500,\n" +
                    "  \"endTimeInMinute\": 595\n" +
                    "}";
            Response res = Request.send(_url, _method, _token
                    , json_input_valid, Constants.MAP_PARAMS_NULL);
//        res.prettyPrint();
            LogsHelper.console(this.getClass().getName(), _method, res);
//            JSONObject json_res = new JSONObject(res.asString());
//            String[] keys = {"code","data"};
//            JsonMinh.jsonlackKeys(keys, json_res);
//            Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
//            res.then().statusCode(200);
        }

    }
}
