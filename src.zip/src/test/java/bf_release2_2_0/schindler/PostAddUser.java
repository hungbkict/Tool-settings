package bf_release2_2_0.schindler;

import com.github.dzieciou.testing.curl.CurlRestAssuredConfigFactory;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Prepare;

import static io.restassured.RestAssured.given;

public class PostAddUser {
    public static Response postAddUserValid(){
        String token = Prepare.getTokenSchindler();
        try {
            RestAssuredConfig config = CurlRestAssuredConfigFactory.createConfig();
            return given()
                    .log()
                    .all()
                    .config(config)
                    .header("Authorization", "Bearer " + token)
                    .contentType("application/json")
                    .body(Constants.INPUT_JSON_NULL)
                    .urlEncodingEnabled(false)
                    .post("https://apibuiltin.com:2339/schindler/v1/api/command");

        }
        catch (Exception ex)
        {
            return null;
        }

    }
}
