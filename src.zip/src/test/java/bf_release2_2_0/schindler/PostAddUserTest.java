package bf_release2_2_0.schindler;

import io.restassured.response.Response;
import org.testng.annotations.Test;

public class PostAddUserTest {

    @Test(enabled=true)
    public void postBookElevatorValid() {

        Response res = PostAddUser.postAddUserValid();
        res.prettyPrint();
        res.then().statusCode(200);
//        res.then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schema.json"));
    }
}
