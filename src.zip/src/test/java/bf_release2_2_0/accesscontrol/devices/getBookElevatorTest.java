package bf_release2_2_0.accesscontrol.devices;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class getBookElevatorTest {
    public String _url = Constants.URL_AC + "/devices/bf_release2_2_0.elevator";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    Map<String, Object> map_params = new HashMap<>();
    @Test(enabled=true)
    public void getBookElevatorValid() {

        map_params.put("accessCode", "000318");
        map_params.put("deviceId", "bdaffdcd-1ef7-4bdd-a903-b4f12a8dc8dd");
        map_params.put("fromBlock", "10001");
        map_params.put("fromFloor", "100000");
        map_params.put("toBlock", "10001");
        map_params.put("toFloor", "100001");
        Response res = Request.send(_url, _method, _token
                , "", map_params);
        res.prettyPrint();
        res.then().statusCode(200);
    }

}
