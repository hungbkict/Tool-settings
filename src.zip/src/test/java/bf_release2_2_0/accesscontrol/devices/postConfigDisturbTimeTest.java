package bf_release2_2_0.accesscontrol.devices;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.*;
import org.json.JSONObject;
import org.junit.Assert;
//import org.junit.Test;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class postConfigDisturbTimeTest {
    public String _url = Constants.URL_AC + "/devices/disturb-config-time";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"configTime\": [\n" +
            "    {\n" +
            "      \"endTimeInMinute\": 100,\n" +
            "      \"startTimeInMinute\": 0\n" +
            "    }\n" +
            "  ]\n" +
            "}";
    public String json_output = "{\n" +
            "  \"code\": 200," +
            "  \"message2\": \"string\"\n" +
            "}";

    @Test
    public void postConfigDisturbTimeValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","message2"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }
}
