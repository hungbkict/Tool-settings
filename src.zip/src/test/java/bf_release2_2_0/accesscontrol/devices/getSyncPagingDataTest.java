package bf_release2_2_0.accesscontrol.devices;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getSyncPagingDataTest {
    public String _dvID = "70ae484e-38a0-4c03-8df1-e250ca203937";
    public String _url = Constants.URL_AC + String.format("/devices/%s/sync-paging-data", _dvID);
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_AC;
    Map<String , Object > map_params = new HashMap<>();
    @Test(enabled=true)
    public void getSyncPagingDataValid() {
//        map_params.put("accessCode", "000318");
//        map_params.put("deviceId", "bdaffdcd-1ef7-4bdd-a903-b4f12a8dc8dd");
//        map_params.put("fromBlock", "10001");
//        map_params.put("fromFloor", "100000");
//        map_params.put("toBlock", "10001");
//        map_params.put("toFloor", "100001");
        Response res = Request.send(_url, _method, _token
                , "", map_params);
        res.prettyPrint();
        res.then().statusCode(200);
    }

}
