package bf_release2_2_0.accesscontrol.users;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

public class putUpdateUserInfoTest {
    public String _userID = "594ea893-7b92-41f8-b4cc-e5d2fba6ffc4";
    public String _url = Constants.URL_AC + String.format("/users/%s/update-info", _userID);
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"availableAt\": \"2021-09-12T17:14:49.062Z\",\n" +
            "  \"companyId\": \"4cb443ee-7e39-4ab1-b864-50adeaa99c4d\",\n" +
            "  \"expiredAt\": \"2021-09-12T17:14:49.062Z\"\n" +
            "}";

    @Test
    public void putUpdateUserInfoValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }
}
