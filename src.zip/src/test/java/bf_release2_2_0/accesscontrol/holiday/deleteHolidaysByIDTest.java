package bf_release2_2_0.accesscontrol.holiday;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class deleteHolidaysByIDTest {
    public String orgUnitID = "e4395865-1fc1-4358-87d8-c83a70c56742";
    public String _url = Constants.URL_AC + String.format("/holidays/%s", "fd12d6fc-c8a2-4a77-8170-272cdb0efdaf");
    public String _method = Constants.METHOD_DELETE;
    public String _token = Constants.TOKEN_ROOT;
    Map<String, Object> map_params = new HashMap<>();
    @Test(enabled=true)
    public void allValid() {
//        map_params.put("orgUnitId", orgUnitID);
        Response res = Request.send(_url, _method, _token
                , "", map_params);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

}
