package bf_release2_2_0.elevator.elevator;

import io.restassured.response.Response;
import libraries.BeforeTest;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PostBookElevatorTest extends BeforeTest {
    public String _url = Constants.URL_ELEVATOR + "/elevator/booking-bf_release2_2_0.elevator";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"deviceId\": \"bdaffdcd-1ef7-4bdd-a903-b4f12a8dc8dd\",\n" +
            "  \"deviceType\": \"CAMERA_ACCESS\",\n" +
            "  \"fromBlock\": 10001,\n" +
            "  \"fromFloor\": 100000,\n" +
            "  \"personId\": \"000318\",\n" +
            "  \"toBlock\": 10001,\n" +
            "  \"toFloor\": 100001\n" +
            "}";
    @DataProvider(name="methods")
    public Object[][] methodData(){
        return new Object[][] {
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @DataProvider(name="invalidValues")
    public Object[][] invalData(){
        return new Object[][] {
                {null},
                {""},
                {"      "},
                {"<script>alert('a')</script>"},
                {"<h1>Test</h1>"}
        };
    }

    @DataProvider(name="fieldsValues")
    public Object[][] fieldsData(){
        return new Object[][] {
                {null},
                {""},
                {"      "},
                {"<script>alert('a')</script>"},
                {"<h1>Test</h1>"}
        };
    }


    @Test(enabled=true)
    public void postBookElevatorValid() {

        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","message","error"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(400);
    }

    @Test(enabled=true, dataProvider = "methods")
    public void postBookElevatorInvalidMethod(String method) {
        if (!method.equals(_method)) {
            Response res = Request.send(_url, method, _token
                    , json_input_valid, Constants.MAP_PARAMS_NULL);
            res.prettyPrint();
            res.then().statusCode(405);
        }
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void postBookElevatorInvalidDeviceId(String inVal) {
        JSONObject valid_json_obj = new JSONObject(json_input_valid);
        valid_json_obj.put("deviceId", inVal);
        Response res = Request.send(_url, _method, _token
                , valid_json_obj.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(200);
    }

}
