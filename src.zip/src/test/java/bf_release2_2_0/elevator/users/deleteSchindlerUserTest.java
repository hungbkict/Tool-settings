package bf_release2_2_0.elevator.users;

import io.restassured.response.Response;
import libraries.BeforeTest;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class deleteSchindlerUserTest extends BeforeTest {
    public String _url = Constants.URL_ELEVATOR + "/users";
    public String _method = Constants.METHOD_DELETE;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"personId\": \"000318\"\n" +
            "}";
    @DataProvider(name="methods")
    public Object[][] methodData(){
        return new Object[][] {
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @DataProvider(name="invalidValues")
    public Object[][] invalData(){
        return new Object[][] {
                {null},
                {""},
                {"      "},
                {"<script>alert('a')</script>"},
                {"<h1>Test</h1>"}
        };
    }

    @Test(enabled=true)
    public void deleteSchindlerUserValid() {

        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

    @Test(enabled=true, dataProvider = "methods")
    public void deleteSchindlerUserInvalidMethod(String method) {
        if (method.equals(Constants.METHOD_POST)){
            Assert.assertTrue("Skip test",true);
        }
        else if (!method.equals(_method)) {
            Response res = Request.send(_url, method, _token
                    , json_input_valid, Constants.MAP_PARAMS_NULL);
            res.prettyPrint();
            res.then().statusCode(405);
        }
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void deleteSchindlerUserInvalidDeviceId(String inVal) {
        JSONObject valid_json_obj = new JSONObject(json_input_valid);
        valid_json_obj.put("personId", inVal);
        Response res = Request.send(_url, _method, _token
                , valid_json_obj.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(400);
    }

}

