package libraries;

import io.restassured.RestAssured;
import io.restassured.config.LogConfig;
import org.apache.commons.io.output.WriterOutputStream;
import org.testng.annotations.*;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

public class BeforeTest {
    @BeforeClass
    public static void preLog() {

//        RestAssured.
        try {

            FileWriter fileWriter = new FileWriter("output/logs.txt");
            PrintStream printStream = new PrintStream(new WriterOutputStream(fileWriter), true);
            RestAssured.config = RestAssured.config().logConfig(LogConfig.logConfig().defaultStream(printStream));
        }

        catch (IOException e) {
            e.printStackTrace();
        }
    }
//
//    @BeforeMethod
//    public void beforeMethod(ITestNGMethod met) {
//        System.out.println("method name:" + met.getMethodName());
//    }
//
//
//    @AfterMethod
//    public void afterMethod(ITestResult result) {
//        System.out.println("method name:" + result.getMethod().getMethodName());
//    }

//
//    @AfterClass
//    public static void postLog() {
//
//        try {
//
//            FileWriter fileWriter = new FileWriter("output/log2.txt");
//            PrintStream printStream = new PrintStream(new WriterOutputStream(fileWriter), true);
//            RestAssured.config = RestAssured.config().logConfig(LogConfig.logConfig().defaultStream(printStream));
//        }
//
//        catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}
