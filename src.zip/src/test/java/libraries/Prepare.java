package libraries;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import libraries.helper.LogsHelper;
import model.Client;
import model.User;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.io.IOException;

import static io.restassured.RestAssured.given;

public class Prepare {

    public static String getTokenCognito() {
        String res = given()
                .contentType("application/json")
                .body(new User("admin", "7RrB9m#YU6fF63E6UJWM#Ut!WcvW&RDZ"))
                .urlEncodingEnabled(false)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/login-with-cognito")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
        String access_token = jsonPath.get("access_token");
        System.out.println("Local admin token: " + access_token);
        return access_token;
    }


    public static String getTokenCognito(String u, String p) {
        String res = given()
                .contentType("application/json")
                .body(new User(u, p))
                .urlEncodingEnabled(false)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/login-with-cognito")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
        String access_token = jsonPath.get("access_token");
        System.out.println("Cognito token: " + access_token);
        return access_token;
    }

    public static String getTokenCognitoExpired(String u, String p) {
        String res = given()
                .contentType("application/json")
                .body(new User(u, p))
                .urlEncodingEnabled(false)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/login-with-cognito")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
        String access_token = jsonPath.get("access_token");
        System.out.println("Cognito expired token: " + access_token);
        String res2 = given()
                .contentType("application/json")
                .header("Authorization", "Bearer " + access_token)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/me/logout")
                .asString();
        return access_token;
    }

    public static String getTokenLDAP() {
        String res = given()
                .contentType("application/json")
                .body(new User("hungnk2", "hung minh1A@"))
                .urlEncodingEnabled(false)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/login-with-ldap")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
        String access_token = jsonPath.get("access_token");
//        System.out.println("getTokenLDAP access_token: " + access_token);
        return access_token;
    }
    public static String getProdTokenLDAP() {
        String res = given()
                .contentType("application/json")
                .body(new User("hungnk2", "hung minh1A@"))
                .urlEncodingEnabled(false)
                .post("https://technopark.vsmart.net/tnp/iam/api/v0/login-with-ldap")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
        String access_token = jsonPath.get("access_token");
        System.out.println("getProdTokenLDAP access_token: " + access_token);
        return access_token;
    }

    public static String getTokenVin3S(String u, String p) {
//        if (u.equals("gmsteam91@gmail.com")) {
//
//            return "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzM2NhY2M1Yi0yZjQzLTRlYjktODQwMC0wMmU4YmFmNjc5NTYiLCJhdWQiOlsib2F1dGgyLXJlc291cmNlIl0sInVzZXJfbmFtZSI6IjMzY2FjYzViLTJmNDMtNGViOS04NDAwLTAyZThiYWY2Nzk1NiIsInNjb3BlIjpbInJlYWQiXSwiZXhwIjoxNjM1NDk3OTg5LCJpYXQiOjE2MzU0OTQzODksImp0aSI6ImIwZDQxYjAzLWMyYjgtNDYwOS1iNGUzLTczNjczMWRjYTliMiIsImNsaWVudF9pZCI6ImYxMzU0OTg2LWU2OTgtNDcxMi1iYTk0LWU5NGIxMGJmMWI1OCJ9.Fej-V1AR9WQYaOVLNDNdGhbtIs2CXFdky_96tgM0Jn9S9nASmyawxgL2YEBRwXjwwH7wHWdolAleI9d4pBeY1oMk3vCDuPQkmg0wsa_Bi2RcRRPyOiyxn8yx52ECsLXDDr7hAKg9wLUdzt5TF_ke7QGJfhuYoxEmHLjyJM3qfSeNMikM_rv272sGExtJoLWRw8OKrAfpRwIr5BppEgjDthG5YA3KSMlYwYKoSS9uZeJvIIMb28j-WQ_cJGYo35ShuJ24LiNTMKhRuu34HCLrrxloj5Cfx-EomYDIlUrEOm4NYqN8FD5NzcZ1k5MWqbotxuJwgXdC6tbYceSbbVKgjg";
//        }
//        if (u.equals("qa.hungnk2@gmail.com")) {
//
//            return "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzM2NhY2M1Yi0yZjQzLTRlYjktODQwMC0wMmU4YmFmNjc5NTYiLCJhdWQiOlsib2F1dGgyLXJlc291cmNlIl0sInVzZXJfbmFtZSI6IjMzY2FjYzViLTJmNDMtNGViOS04NDAwLTAyZThiYWY2Nzk1NiIsInNjb3BlIjpbInJlYWQiXSwiZXhwIjoxNjM1NDk3OTg5LCJpYXQiOjE2MzU0OTQzODksImp0aSI6ImIwZDQxYjAzLWMyYjgtNDYwOS1iNGUzLTczNjczMWRjYTliMiIsImNsaWVudF9pZCI6ImYxMzU0OTg2LWU2OTgtNDcxMi1iYTk0LWU5NGIxMGJmMWI1OCJ9.Fej-V1AR9WQYaOVLNDNdGhbtIs2CXFdky_96tgM0Jn9S9nASmyawxgL2YEBRwXjwwH7wHWdolAleI9d4pBeY1oMk3vCDuPQkmg0wsa_Bi2RcRRPyOiyxn8yx52ECsLXDDr7hAKg9wLUdzt5TF_ke7QGJfhuYoxEmHLjyJM3qfSeNMikM_rv272sGExtJoLWRw8OKrAfpRwIr5BppEgjDthG5YA3KSMlYwYKoSS9uZeJvIIMb28j-WQ_cJGYo35ShuJ24LiNTMKhRuu34HCLrrxloj5Cfx-EomYDIlUrEOm4NYqN8FD5NzcZ1k5MWqbotxuJwgXdC6tbYceSbbVKgjg";
//        }
        if (u.equals("")) {
            u = "qa.hungnk2@gmail.com";
        }
        if (p.equals("")) {
            p = "vinhkien1A@";
        }
        String res = given()
                .contentType("application/json")
                .body(new User(u, p))
//                .body(new User("gmsteam91@gmail.com", "Yhoamy2020@"))
                .urlEncodingEnabled(false)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/login")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
        String access_token = jsonPath.get("access_token");
        System.out.println(" Response: " + res);
        System.out.println("UserTokenVin3S " + u + " access_token: " + access_token);
        return access_token;
    }

    public static String getTokenSchindler() {
        String res = given()
                .contentType("application/json")
                .body(new User("vinsmart", "windup-virtuous-sawyer-dilute-neural-sewing-palette-urbane-concave-FILIPINO-soapsuds-fracture-lassie-cheat-cheer"))
                .urlEncodingEnabled(false)
                .post("https://apibuiltin.com:2339/schindler/v1/api/login")
                .asString();
        JSONArray jsonArray = new JSONArray(res);
        JSONObject authen = jsonArray.getJSONObject(0);
        String access_token = authen.getString("token");

            return access_token;
        }

    public static String getTokenAC() {
        String res = given()
                .contentType("application/json")
                .body(new Client("f1354986-e698-4712-ba94-e94b10bf1b58", "fe2cd8c5-03b4-465c-9007-27eda0a99226"))
                .urlEncodingEnabled(false)
                .post("https://technopark.vsmart.net/tnp/iam/api/v0/client/login")
                .asString();
        JsonPath jsonPath = new JsonPath(res);
//        System.out.println("Ac res: "+res);
        String access_token = jsonPath.get("access_token");
        return access_token;
    }

    @Test
    public void tokenAC(String id) throws IOException {
        getTokenAC();
    }
}
