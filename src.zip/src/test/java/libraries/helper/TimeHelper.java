package libraries.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeHelper {

    public static String dtFormated() {
        DateFormat df = new SimpleDateFormat("yyyyMMdd_hhmmss");
        return df.format(new Date()).toString();
    }

    public static Long timeNow() {
        return System.currentTimeMillis();
    }

    public static Long timeTomorrow() {
        return System.currentTimeMillis() + 86400000;
    }


    public static String timeNowTxt() {
        Long t =  System.currentTimeMillis();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(t);
        return dateFormat.format(date);
    }
    public static String dateToday() {
        Long t =  System.currentTimeMillis();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(t);
        return dateFormat.format(date);
    }

    public static String timeTomorrowTxt() {
        Long t =  System.currentTimeMillis()+86400000;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(t);
        return dateFormat.format(date);
    }

    public static String dateTomorrow() {
        Long t =  System.currentTimeMillis()+86400000;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(t);
        return dateFormat.format(date);
    }


    public static Long timeMoreOneWeek(){
        return System.currentTimeMillis()+86400000*7;
    }

    public static String timeMoreOneWeekTxt(){
        Long t =  System.currentTimeMillis()+86400000*7;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(t);
        return dateFormat.format(date);
    }

    public static Long timeLessOneWeek(){
        return System.currentTimeMillis()-86400000*7;
    }

    public static String timeLessOneWeekTxt(){
        Long t =  System.currentTimeMillis()-86400000*7;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(t);
        return dateFormat.format(date);
    }

    public static Long timeMoreOneMonth(){
        return System.currentTimeMillis()+86400000*30;
    }

    public static String timeMoreOneMonthTxt(){
        Long t =  System.currentTimeMillis()+86400000*30;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(t);
        return dateFormat.format(date);
    }

    public static Long timeLessOneMonth(){
        return System.currentTimeMillis()-86400000*30;
    }

    public static String timeLessOneMonthTxt(){
        Long t = System.currentTimeMillis()-86400000*30;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(t);
        return dateFormat.format(date);
    }
}
