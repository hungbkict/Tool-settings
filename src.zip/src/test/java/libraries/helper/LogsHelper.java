package libraries.helper;

import io.restassured.response.Response;
import libraries.Constants;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.platform.commons.util.StringUtils;

import java.io.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ResourceBundle;

public class LogsHelper {
    public static ResourceBundle rb = ResourceBundle.getBundle("settings");

    public static void write_to_file(String classname, String content) throws IOException {
        String path = "src/test/java/" + classname.replace(".", "/") + ".json";
        BufferedWriter writer = new BufferedWriter(new FileWriter(path));
        writer.write(content);
        writer.close();
    }

    public static void report(String module, String resource, String path, String method, long resTime) throws IOException {

//        Report.submit(module, resource, path, method, resTime);

//        Write to file only
        String file_path = "libraries/external/reports";
        module = module.replace("_","-");
        module = module.toLowerCase();
        String base_url= "uat2-api-grandpark.vsmart.net/gp/"+module+"/api/v0";
//        write_to_file(file_path,  "", false);
//        write_to_file(file_path,  "[", true);
        String body_json = "{\n" +
                "    \"base_url\": \""+base_url+"\",\n" +
                "    \"resource\": \""+resource+"\",\n" +
                "    \"path\": \""+path+"\",\n" +
                "    \"method\": \""+method+"\",\n" +
                "    \"response_time\": "+resTime+"\n" +
                "  },\n" ;
        write_to_file(file_path,  body_json, true);
//        write_to_file(file_path,  "]", true);

    }



    public static void save_to_file(String path1, String name, Response res) throws IOException {
        String path = "src/test/java/" + path1.replace(".", "/") + name;
        byte[] img = res.asByteArray();
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(path);
            fos.write(img);
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void write_to_file(String classname, String content, Boolean append) throws IOException {
        String path = "src/test/java/" + classname.replace(".", "/") + ".json";
        BufferedWriter writer = new BufferedWriter(new FileWriter(path, append));
        writer.write(content);
        writer.close();
    }

    public static void write_to_file(String classname, String ext, String content, Boolean append) throws IOException {
        String path = "src/test/java/" + classname.replace(".", "/") + "."+ext;
        BufferedWriter writer = new BufferedWriter(new FileWriter(path, append));
        writer.write(content+ "\r\n");
        writer.close();
    }

    public static Boolean download_file(String classname, String ext, Response res) throws IOException {
        String path = "src/test/java/" + classname.replace(".", "/") + "." + ext;
        byte[] byte_arr = res.asByteArray();
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(path);
            fos.write(byte_arr);
            fos.close();
            File downloaded = new File(path);
            System.out.println("Size: " + downloaded.length());
            return downloaded.length() > 100;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

    }

    public static void write_to_file(String classname, String ext, String content) throws IOException {
        String path = "src/test/java/" + classname.replace(".", "/") + "." + ext;
        BufferedWriter writer = new BufferedWriter(new FileWriter(path));
        writer.write(content);
        writer.close();
    }

    public static void print_keys(String json_arr, String in_view, String in_commnet) {
        JSONArray arr = new JSONArray(json_arr);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject data = (JSONObject) arr.get(i);
            System.out.println("\"" + data.getString(in_view) + "\",//" + data.getString(in_commnet));
        }
    }

    public static void console(String classname, String method, Response res) throws IOException {
        if (rb.getString("logging.pretty_print").equals("yes")) {
            res.prettyPrint();
        }
        if (method.equals(Constants.METHOD_GET) && rb.getString("logging.write_get_to_file").equals("yes")) {
            write_to_file(classname, res.asString());
        }
    }

    public static void console(Response res) {
        if (rb.getString("logging.pretty_print").equals("yes")) {
            res.prettyPrint();
        }
    }

    public static void consoleJson(String json) {
        System.out.println(beautiful(json));
    }

    public static String beautiful(String input) {
        int tabCount = 0;

        StringBuilder inputBuilder = new StringBuilder();
        char[] inputChar = input.toCharArray();

        for (int i = 0; i < inputChar.length; i++) {
            String charI = String.valueOf(inputChar[i]);
            if (charI.equals("}") || charI.equals("]")) {
                tabCount--;
                if (!String.valueOf(inputChar[i - 1]).equals("[") && !String.valueOf(inputChar[i - 1]).equals("{"))
                    inputBuilder.append(newLine(tabCount));
            }
            inputBuilder.append(charI);

            if (charI.equals("{") || charI.equals("[")) {
                tabCount++;
                if (String.valueOf(inputChar[i + 1]).equals("]") || String.valueOf(inputChar[i + 1]).equals("}"))
                    continue;

                inputBuilder.append(newLine(tabCount));
            }

            if (charI.equals(",")) {
                inputBuilder.append(newLine(tabCount));
            }
        }

        return inputBuilder.toString();
    }

    private static String newLine(int tabCount) {
        StringBuilder builder = new StringBuilder();

        builder.append("\n");
        for (int j = 0; j < tabCount; j++)
            builder.append("  ");

        return builder.toString();
    }
}
