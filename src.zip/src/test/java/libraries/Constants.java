package libraries;
import java.util.HashMap;
import java.util.Map;
public class Constants {

    public static String URL_AC = "https://technopark.vsmart.net/tnp/access-control/api/v0";
    public static String URL_PROD_AC = "https://technopark.vsmart.net/tnp/access-control/api/v0";
    public static String URL_GUEST = "https://uat-technopark.vsmart.net/tnp/guest-registration/api/v0";
    public static String URL_GUEST_REGISTRATION = "https://uat-technopark.vsmart.net/tnp/guest-registration/api/v0";
    public static String URL_IAM = "https://uat-technopark.vsmart.net/tnp/iam/api/v0";
    public static String URL_PROD_IAM = "https://technopark.vsmart.net/tnp/iam/api/v0";
    public static String URL_APP_BE = "https://uat-technopark.vsmart.net/tnp/app-be/api/v0";
    public static String URL_ELEVATOR = "https://uat-technopark.vsmart.net/tnp/elevator/api/v0";
    public static String URL_WEATHER = "https://uat-technopark.vsmart.net/tnp/weather/api/v0";

    public static final String TOKEN_ROOT = "user_root";
    public static final String TOKEN_PROD = "user_prod";
    public static final String TOKEN_ADMIN = "user_root";
    public static final String TOKEN_SYS_MANAGEMENT = "user_ldap";
    public static final String TOKEN_OFFICE_MANAGER = "tk_om";
    public static final String TOKEN_STAFF = "vin3s_thai";
    public static final String TOKEN_STAFF2 = "vin3s_staff_quynh";
    public static final String TOKEN_AC = "access_control";
    public static final String TOKEN_PROD_HUNGNK = "hungnk";
    public static final String TOKEN_HUNGNK = "hungnk";
    public static final String TOKEN_REAL = "real___token";
    public static final String TOKEN_SCHINDLER = "schindler";
    public static final String TOKEN_EMPTY = "token_empty";
    public static final String TOKEN_NULL = "no_set_header";
    public static final String TOKEN_USER_SPACE = "user_space";
    public static final String METHOD_GET = "get";
    public static final String METHOD_POST = "post";
    public static final String METHOD_PUT = "put";
    public static final String METHOD_PATCH = "patch";
    public static final String METHOD_DELETE = "delete";

    public static final Integer STATUS_CODE_200 = 200;
    public static final Integer STATUS_CODE_201 = 201;
    public static final Integer STATUS_CODE_400 = 400;
    public static final Integer STATUS_CODE_401 = 401;
    public static final Integer STATUS_CODE_403 = 403;
    public static final Integer STATUS_CODE_405 = 405;
    public static final Integer STATUS_CODE_4004009 = 4004009;
    public static final Boolean VALIDATE_BODY_RES_YES = true;

    public static String[] METHODS = {METHOD_GET, METHOD_POST, METHOD_PUT, METHOD_PATCH, METHOD_DELETE};

    public static String[] DEFAULT_RESPONSE_KEYS = {"code", "data"};
    public static String INPUT_JSON_NULL = "";

    public static Map<String, Object> MAP_PARAMS_NULL = new HashMap<>();

}
