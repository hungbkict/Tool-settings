package libraries;
import com.github.dzieciou.testing.curl.CurlRestAssuredConfigFactory;
import com.github.dzieciou.testing.curl.Options;
import com.github.dzieciou.testing.curl.Platform;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import libraries.helper.TextHelper;
import org.apache.commons.lang3.ArrayUtils;
import org.json.JSONObject;
import org.junit.Assert;

import java.util.Map;

import static io.restassured.RestAssured.given;

public class Request{

    public static String getToken(String tokenType){
//        if (tokenType.contains(Constants.TOKEN_REAL)){
//            System.out.println("Input real token");
//            return tokenType.replace(Constants.TOKEN_REAL,"");
//        }
        switch (tokenType) {
            case Constants.TOKEN_ROOT:
                System.out.println("Role: ROOT   Account local Admin");
                return "Bearer " + Prepare.getTokenCognito();
            case Constants.TOKEN_PROD_HUNGNK:
                System.out.println("Role: ROOT   Account local Admin");
                return "Bearer " + Prepare.getTokenCognito("hungnk_1636014361571","Vsm1234@");
//                return "Bearer " + Prepare.getTokenCognito("hungnk_1636100450649","Vsm1234@");
            case Constants.TOKEN_PROD:
                System.out.println("Role: ROOT   Account local Admin");
                return "Bearer " + Prepare.getProdTokenLDAP();
            case Constants.TOKEN_SYS_MANAGEMENT:
                System.out.println("Role: SYS_MANAGEMENT   Account LDAP hungnk2");
                return "Bearer " + Prepare.getTokenLDAP();
            case Constants.TOKEN_OFFICE_MANAGER:
                System.out.println("Role: OFFICE_MANAGER");
//                return "Bearer " + Prepare.getTokenCognito("adminvsm","Vsm@1234");
                return "Bearer " + Prepare.getTokenVin3S("qa.hungnk2@gmail.com", "vinhkien1A@");
            case Constants.TOKEN_STAFF:
                System.out.println("Role: STAFF");
                return "Bearer " + Prepare.getTokenVin3S("gmsteam91@gmail.com", "Yhoamy2020@");
            case Constants.TOKEN_STAFF2:
                System.out.println("Role: STAFF2");
                return "Bearer " + Prepare.getTokenVin3S("quynhluu1996@gmail.com", "Vsm@1234");
            case Constants.TOKEN_EMPTY:
                return "";
            case Constants.TOKEN_USER_SPACE:
                return "   " + Prepare.getTokenCognito();
            case Constants.TOKEN_AC:
                return "Bearer " + Prepare.getTokenAC();
            case Constants.TOKEN_SCHINDLER:
                return "Bearer " + Prepare.getTokenSchindler();
            case Constants.TOKEN_REAL:
                return "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2NmNiZmVhNS02YzFlLTRhZDQtOWYyNy1jYWM3OTI0MjFiMzYiLCJhdWQiOlsib2F1dGgyLXJlc291cmNlIl0sInVzZXJfbmFtZSI6IjY2Y2JmZWE1LTZjMWUtNGFkNC05ZjI3LWNhYzc5MjQyMWIzNiIsInNjb3BlIjpbInJlYWQiXSwiZXhwIjoxNjUyODk3ODAxLCJpYXQiOjE2NTI4OTQyMDEsImp0aSI6ImQ3ODk2OGZjLTViNzAtNDZhNS05NTMzLWJmYWFkOGNiZTYxMyIsImNsaWVudF9pZCI6ImYxMzU0OTg2LWU2OTgtNDcxMi1iYTk0LWU5NGIxMGJmMWI1OCJ9.bMulTj6wXdVcv9NOFbvS2Oh1uzMrCDbRh8XswcRx7K3NLhi6OPS6NZbXzCi-T5ym4uqwfRNbUhZDcUEawZAP0qB87n6f6ljJOD_TjIQhayYb24AFQq2yXidV5w97k0tw4aiweVq6L7m1gmejujixptj5HPlBoZV1E7PIvfyP0FDTk2g3X0VDKT-yr9x8iqkCafadNTvvO-I12aJMfClfO1Qx4rUyqv5MPidHFFr4Js7bkVl4xwvBh1usbxEsXwkVWarA4FXZoZK75AepkCEBbR-B3EipFA1mQmTHVIM1IuJ-tTLXfoXMsAsuVvYA03udm5O3Ynta4zkwkCXZt7KVNA";
            default:
                return "";

        }
    }

    //    public static String send_get_data(String url, String method, String tokenType, String body_json, Map<String, Object> params){
    public static JSONObject send_get_data(String url, String method, String tokenType, String body_json, Map<String, Object> params) {
        Response res = Request.send(url, method, tokenType
                , body_json, params);
        System.out.println("Response:");
        JSONObject json_res = new JSONObject(res.asString());
        return json_res;
    }

    public static void send_validate(String url, String method, String tokenType, String body_json,
                                     Map<String, Object> params, Integer statusCode, String[] keys) {
        Response res = Request.send(url, method, tokenType
                , body_json, params);
        System.out.println("Response:");
        res.prettyPrint();
        res.then().statusCode(statusCode);
        if (keys != null) {
//        if (!keys.equals(null)) {
            JSONObject json_res = new JSONObject(res.asString());
            JsonMinh.jsonlackKeys(keys, json_res);
            Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        }
    }

    public static void send_validate(String url, String method, String tokenType, String body_json,
                                     Map<String, Object> params, Integer statusCode, String[] keys, Boolean isValidateBodyCode) {

        Response res = Request.send(url, method, tokenType
                , body_json, params);
        System.out.println("Response:");
        res.prettyPrint();

        JSONObject json_res = new JSONObject(res.asString());
        if (isValidateBodyCode) {
            Integer bd_code = json_res.getInt("code");
            Assert.assertTrue(bd_code.equals(statusCode));
        } else {
            res.then().statusCode(statusCode);
        }
        if (!keys.equals(null)) {
            JsonMinh.jsonlackKeys(keys, json_res);
            Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        }
    }

    public static Response send(String url, String method, String tokenType, String body_json, Map<String, Object> params) {

        Options options = Options
                .builder()
                .printMultiliner()
                .targetPlatform(Platform.UNIX)  //để không nháy đôi giá kí tự "" trong data-binary
                .useLongForm() //để hiện --header thay vì -H
                .build();
        RestAssuredConfig config = CurlRestAssuredConfigFactory.createConfig(options);

        RequestSpecification rs = given()
                .log()
                .all()
//                .filter(new AllureRestAssured())
//                .config(config)
                .relaxedHTTPSValidation()
                .contentType("application/json")
                .urlEncodingEnabled(false);
        if (!tokenType.equals(Constants.TOKEN_NULL)){
            String token = getToken(tokenType);
            rs.header("Authorization", token);
        }
        if (!body_json.equals("")){
            body_json = TextHelper.escapeNewLine(body_json);
            rs.body(body_json);
        }
        if (!params.isEmpty()) {
            rs.params(params);
        }
        if (ArrayUtils.contains(Constants.METHODS, method)) {
            return rs.request(method, url);
        } else {
            return null;
        }

    }

}
