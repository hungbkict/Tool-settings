package a_support;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class clearCompaniesTest {

    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @Test(priority = 1)
    @Severity(SeverityLevel.CRITICAL)
    @Description("All variables valid")

    public void allValid(){
        String[] rm_companies = new String[]{
                "dbe3c563-0509-49bb-a714-0cf41a45cd7f",//công việc 7
//                    "e0f62d48-e14a-4f50-8a0e-c8f66aa05e4f",//Vantix
                "bb97c369-2826-4249-8cd2-b08040fc4759",//Phòng phát triển dịch vụ (Vin3s)
                "bb97c369-2826-4249-8cd2-b08040fc4769",//Viện phát triển sản phẩm (Vinsmart)
                "396893c4-47ee-4ebb-a8dd-40af80100174",//Trung tâm kiểm soát chất lượng sản phẩm
                "bb97c369-2826-4249-8cd2-b08040fc4779",//Phòng phát triển dịch vụ (Vinsmart)
                "7571ced3-86cd-4a6b-9c79-f0d99d1dfc27",//QUẢN LÝ TÒA NHÀ
                "0e2a7be9-e4cd-416c-ac19-4f1132322588",//21312
                "1c099763-b6d9-46e6-842c-99f76b021759",//Co
                "c6ff898d-4877-4a20-8248-c09ad7949626",//QA CHECK 1
                "16bb53c0-7254-4b14-92b7-fab7a25040d6",//qa
                "98ecafb4-4b0f-430b-9710-4efc0126a399",//Fanvist con
                "2d60344b-4be0-4c32-92c5-aeae653381f1",//công ty 1
                "7a755706-246d-4149-b9dc-1a23a2c9138e",//LEO_COMPANY
                "c1786b23-4dbc-4a3a-81d6-264063f15b9a",//12412
                "166e223b-c924-4309-beb5-989be63a883f",//vsmart
                "4e2fc7f3-e5b2-4bb3-81b5-d6626c2704bc",//hdz
                "6b337c23-17d6-4e68-97f5-e1da8ccb251f",//Công ty 001
                "b40de5eb-9b29-4c10-bafc-60c64b9225cb",//Co 6
                "7191d255-13ed-4e3f-83cb-6dd8d804e4ab",//12312
                "0f2f6613-0694-46f5-9bc9-cb9a699543c2",//Co 5
                "45d8b46e-afb0-4fe0-a5ca-adfd06449e8b",//Fanvist 12
                "88c7ee60-a205-4bf0-8453-d9533222f988",//vcđsf
//                    "083b5555-41d3-4911-a045-819023591878",//QA_test
                "fc7ef22c-7746-4c68-88c5-da32ac4dd0c0",//viet
                "baa8f5fb-8759-42b5-a283-5686b90794de",//vaqe
                "ba2a8880-bff6-4b73-9518-640721c2a70b",//vaaaaaaaa
                "903b53bd-f2b5-4221-8e93-d3c1289f7e0e",//vterer
                "20ae4311-1148-442e-87f6-7d333e7dbc7b",//vfefe
                "737ceebe-b5ef-4e36-be42-cf83fbefedd2",//vrerreww
                "6954af2c-9f8f-47bf-8f18-1c4f11f93a8d",//vfdgerw
                "f766cc14-75a7-406d-b05a-9256e0b44e8d",//ctytesst
                "58245f32-2637-48a4-a492-06046cd29152",//vfffffffe
                "f02f3eca-e85c-4c13-8a9d-29b4bc2a3152",//công ty2
                "bb97c369-2826-4249-8cd2-b08040fc4749",//Viện phát triển sản phẩm (Vin3s)
                "f3dca968-9872-4c92-b79c-b19a166314e1",//MỘT CÔNG TY XA LẠ
//                    "bb97c369-2826-4249-8cd2-b08040fc4719",//Vin3s
//                    "bb97c369-2826-4249-8cd2-b08040fc4729",//Evotek
                "658a87e8-ab49-423d-b73f-1e04aeedfe55",//công ty 121432
                "8209dafc-23c0-47a8-bcd5-f88d704a82ab",//43534
                "562b95e7-830c-42b4-8e6c-39c4b69d0e38",//Công ty Yến sào Hoàng Việt
                "170545d6-562a-43e4-8c7a-07c7b14e55dc",//công ty 111
                "bc373586-e5b8-457c-acc0-0c6b570129b8",//công ty 1232
                "6d20d358-618e-4ed5-ab33-18d23c14eeef",//LEO_CREATE_ORG_1628560254
                "20e9471a-4a96-4e32-823b-fbaa2e87bb68",//LEO_CREATE_ORG_1628690611
                "2f39ffc0-627a-44b5-8c7e-5f8d8d441b4c",//LEO_CREATE_ORG_1628690624
                "dbf0df60-3dfb-4e57-ba22-d0985dce515c",//công ty 11222
                "6f91d615-5065-48e4-899b-84229d096522",//Đơn vị 1
                "afa1bf8b-f774-4f18-b5c6-f49914534df5",//đơn vị  test
                "e4395865-1fc1-4358-87d8-c83a70c56742",//StartUp Hùng test
                "752095a2-9fa4-46d6-8947-4bbbf3423a78",//test123
                "14890106-07b2-4f86-959b-83d6e390ea60",//1234
                "db422d26-6a1d-4f37-bdc3-4fd8652ac8e1",//2333
//                    "db134b5c-112e-477d-aca1-f4a385ad6694",//Thai Test
                "08533aff-6282-4b63-a5d4-675587640347",//Công ty H2
                "b76646b6-2dad-4cc9-84c2-17a6380b52df",//Vinsmart1629052679
//                    "547aedb3-b9eb-4241-b9f0-16cfe9a12a63",//Duy Test
                "d05cbe59-c252-4d5e-a504-c3762dbbb818",//Công ty 1 thành viên tự biên tự diễn 1
                "d7ad44c8-a2c4-49a5-a34c-f8312a0be495",//vvfff
                "f6d444a4-6afe-45d5-80ec-882c658edb74",//ttttqw
                "05383a56-09cb-4da8-9038-e34966f7fa55",//123
                "1fb8777a-4313-47a9-8cbc-595d8fcf1f90",//121212
//                    "bb97c369-2826-4249-8cd2-b08040fc4739",//Vinsmart
                "483cbe24-9e92-4c2e-a665-19f53075ad95",//Đông Test
                "08c33da0-d957-4700-946f-72797331a927",//Công ty 1 thành viên tự biên tự diễn 9
                "6eb7fa00-85aa-48b5-9511-a3b7bba0ef2e",//Công ty 1 thành viên tự biên tự diễn 24
                "e0ea047e-8d22-44fa-b3ff-1cccb3d3e9e2",//hieunt test
                "85651523-d542-4aef-87bf-9f116ddb0b55",//Công ty 1 thành viên tự biên tự diễn 8
                "60a2dfa3-f557-4cb0-9b66-812a493d4ece",//Phucnd5
                "65b6e82e-caa9-4f34-9b6d-ba212e2e9b0f",//Công ty 1 thành viên tự biên tự diễn 10
//                    "8b735625-211a-4a2d-ae7d-4c304eef5e7e",//VMS
//                    "33cf03eb-ed67-4626-b852-f90b788f88f2",//Vinfast
//                    "4cb443ee-7e39-4ab1-b864-50adeaa99c4d",//Vinsmart City
                "e2263f1b-d55c-4f7d-acb1-35e5b7d7d984",//Công ty 1 thành viên tự biên tự diễn 26
                "d036d94c-73a1-4434-a6b7-374df237cb60",//THÁI TEST 2
                "767bf7c7-2f30-484b-bd7f-bf73050a99f7",//Công ty 1 thành viên tự biên tự diễn 25
                "a41949c3-c807-46b3-8a26-a0caba6d2cd9",//P&L2 thuộc Vingroup
                "15e2315c-7951-4507-b3c8-0a5148731343",//Công ty 1 thành viên tự biên tự diễn 115
                "fe9ebeec-3ad0-4cbe-919c-8e16367d6f9c",//Công ty 1 thành viên tự biên tự diễn 22
                "c58f7abd-9647-4875-98aa-df9dc04c12de",//Vinsmart1629049783
                "1a259d91-6851-4f29-aaf0-fede8e96dd4d",//Công ty 1 thành viên tự biên tự diễn 3
//                    "10e926a0-0d36-4db7-9ce2-3e5441ce6ae9",//Vinhomes
                "47c0ae69-e959-4095-a22a-d2b3887c5c94",//Nguyễn Lương Mạnh test
                "83ed3709-95a6-47e4-9ca0-0d8cacfb08ed",//Công ty 1 thành viên tự biên tự diễn 4
                "f10a3c59-c1dc-4088-9118-e3bd0556a754",//Test
                "b9ed5dc8-ca8c-4863-99be-10e2ad57f4d7",//Công ty 1 thành viên tự biên tự diễn 7
                "52358f31-cb17-4c4a-bf36-bececa2cfe0a",//Công ty 1 thành viên tự biên tự diễn 23
                "9383d7ab-af06-4ad2-86ae-6c971385c9a0",//Công ty độc lập 1
                "5c3343e9-65d9-4a82-a7d2-d49d54bdc76f",//Công ty 1 thành viên tự biên tự diễn
                "cdb3e37c-dc8b-4c45-8cf5-1f2218e00e5c",//Công ty 1 thành viên tự biên tự diễn 2
                "7d8a6125-27fb-44ad-8483-4035ee7530e9",//P&L1 thuộc Vingroup
                "f3d661de-83ef-4077-8d56-494f344424e0",//Công ty độc lập 2
                "f90a89ed-bfde-4995-890c-d122944ad2e0",//P&L3 thuộc Vingroup
                "918672de-df24-498a-9f5a-c63ba830db98",//Công ty H1
                "bd4b6fb5-df74-4319-8a4d-7d46ce17d8f0",//công ty độc lập 3
                "e28d5c82-d59f-4161-905a-bb9828759fd6",//P&L4 thuộc Vingroup
                "eb886f75-8732-42da-a9e9-8bda336cbca7",//4Vinsmart
                "ea0b836c-93cf-457d-ac41-d780fad7b145",//hung1031
        };
        for (String id: rm_companies){
//            String url = Constants.URL_IAM + "/org-units/562b95e7-830c-42b4-8e6c-39c4b69d0e38";
            String url = Constants.URL_IAM + "/org-units/"+id;
            Response res = Request.send(url, Constants.METHOD_DELETE, _token
                    , json_input_valid, map_params);
            res.prettyPrint();
        }
//         json_input_valid = "{\n" +
//                "  \"status\": \"INACTIVE\"\n" +
//                "}";
//        for (String id: rm_companies){
//            String url = Constants.URL_IAM + "/org-units/"+id;
//            Response res = Request.send(url, Constants.METHOD_PUT, _token
//                    , json_input_valid, map_params);
//            res.prettyPrint();
//        }


    }

}
