package a_support;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TextHelper;
import libraries.helper.TimeHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class clearUserTest {
    public String _url = Constants.URL_IAM + "/users/search";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @Test(priority = 1)
    @Severity(SeverityLevel.CRITICAL)
    @Description("All variables valid")
    public void getListUser() throws JSONException {
        map_params.put("page",6);
        map_params.put("limit",100);
//        map_params.put("orgUnitIds","dbe3c563-0509-49bb-a714-0cf41a45cd7f");
        Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
//         res.prettyPrint();
        JSONObject res_all = new JSONObject(res.asString());
        JSONObject data_all = (JSONObject) res_all.getJSONObject("data");
        JSONArray res_data= data_all.getJSONArray("rows");

        for (int i = 0; i < res_data.length(); i++) {
//            System.out.println(res_data.get(i).toString());
            JSONObject data = (JSONObject) res_data.get(i);

//            System.out.println(data.toString());
            String fname = data. isNull("fullName") ? "" : data.getString("fullName");
            String employeeCode = TimeHelper.timeNow().toString();
            String phoneNumber = "09"+ TextHelper.randomInt(1111111,9999999);
            System.out.println("\""+data.getString("id")+"\",//"+data.getString("username")+";   "+fname+";  Cong ty: "+data.getString("orgUnitName"));

            String json_input_valid2 = "{\n" +
                    "  \"userId\": \""+data.getString("id")+"\",\n" +
                    "  \"default\": true,\n" +
                    "  \"status\": \"ACTIVE\",\n" +
                    "  \"email\": \""+data.getString("email")+"\",\n" +
                    "  \"username\": \""+data.getString("username")+"\",\n" +
                    "  \"employeeCode\": \""+employeeCode+"\",\n" +
                    "  \"mobile\": \""+phoneNumber+"\",\n" +
                    "  \"fullName\": \""+fname+"\",\n" +
                    "  \"orgUnitId\": \"bb97c369-2826-4249-8cd2-b08040fc4739\"\n" +
                    "}";
            String url2 = Constants.URL_IAM + "/users/";
            Response res2 = Request.send(url2, Constants.METHOD_PUT, _token
                    , json_input_valid2, Constants.MAP_PARAMS_NULL);
//            res.prettyPrint();
        }

    }

    @Test(priority = 1)
    public void allValid(){
        String[] change_companies = new String[]{
                "00ba9380-d64d-40e7-9d07-a031cc54900d",//huong1;   6 tháng_2;  Cong ty: công việc 7
        };
        for (String id: change_companies){
            json_input_valid = "{\n" +
                "  \"userId\": \""+id+"\",\n" +
                "  \"orgUnitId\": \"bb97c369-2826-4249-8cd2-b08040fc4739\"\n" +
                "}";
            String url = Constants.URL_IAM + "/users/";
            Response res = Request.send(url, Constants.METHOD_PUT, _token
                    , json_input_valid, map_params);
            res.prettyPrint();
        }
    }
}
