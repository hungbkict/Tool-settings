package a_support;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class doorWithDevicesTest {
    public String _url = Constants.URL_PROD_AC + "/doors";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_PROD_HUNGNK;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @Test(priority = 1)
    @Severity(SeverityLevel.CRITICAL)
    @Description("All variables valid")
    public void getListUser() throws JSONException {
        map_params.put("page",1);
        map_params.put("limit",100);
//        map_params.put("orgUnitIds","dbe3c563-0509-49bb-a714-0cf41a45cd7f");
        Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
//         res.prettyPrint();
        JSONObject res_all = new JSONObject(res.asString());
        JSONObject data_all = (JSONObject) res_all.getJSONObject("data");
        JSONArray res_data= data_all.getJSONArray("rows");

        for (int i = 0; i < res_data.length(); i++) {
            JSONObject data = (JSONObject) res_data.get(i);
            List<String> dv_list = new ArrayList<>();
//            String dv_list = "";
            JSONArray dv_arr = data.getJSONArray("devices");
            for (int j = 0; j < dv_arr.length() ; j++) {
                JSONObject dv_data = (JSONObject) dv_arr.get(j);
                dv_list.add(dv_data.getString("name"));
            }
            String name = data. isNull("name") ? "" : data.getString("name");
            System.out.println("(Door) "+name+" have "+ String.join(", ", dv_list));
        }

    }
    /*
    Device: CUONG_1421621004970 have  , Access Control 1421621004970
Device: Thien_2987 have  , Access Control 1424220052987
Device: Manhdv5 test 0.6.0_2469, 2458 have  , Access Control 1421821002458 , Access Control 1421821002469
Device: CuongLH_1835 have  , Access Control 1424220051835
Device: [DEV] TNP have  , Access Control 1424220051844 , Access Control 1424220051841
Device: [DEV] thangtd9 have  , Access Control 1424220053325
Device: C1_HIEUHT18 have  , VF_DEMO_01
Device: Victor_Door have  , Access Control 1421621004781
Device: QUYNHLV_6893 have  , Access Control 1422721166893
Device: [DEV] TNP Sảnh have  , Access Control 1421821002451 , Access Control 1422721167594
Device: Cuonglh8_4969_2458 have  , Access Control 1421621004969
Device: duongnd7 Quản lý cửa kiểm soát have  , Access Control 1422721167738 , Access Control 1424220053621
Device: Cuong_7898_9054 have  , Access Control 1422721167898 , Access Control 1422921039054
Device: Cuonglh8_6884_9153 have  , Access Control 1422921039153 , Access Control 1422721166884
Device: CuongLh8_7896_8998 have  , Access Control 1422721167896 , Access Control 1422921038998
Device: Cuonglh8_7408_4779 have  , Access Control 1422721167408 , Access Control 1421621004779
Device: Cuonglh8_7115 have  , Access Control 1422721167115
Device: cuonglh8_6877_9098 have  , Access Control 1422721166877 , Access Control 1422921039098
Device: Cửa Thiện QA 8995 have
Device: VF_Cửa_VP have  , VF_DEMO_02
Device: VF_Cửa_Kho have

     */
}
