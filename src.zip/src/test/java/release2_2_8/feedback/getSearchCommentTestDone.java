package release2_2_8.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getSearchCommentTestDone {

    public String _url = Constants.URL_APP_BE + "/feedback/comment/search";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
//                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
//                {Constants.METHOD_DELETE},
        };
    }

    @BeforeMethod
    public void init() {
        map_params.put("page", 1);
        map_params.put("limit", 25);
//        map_params.put("keyword", "Thai");
        map_params.put("id", "a429cc29-d6c2-437c-8007-b1b74ac7cd28");
//        map_params.put("types", "EVENT");
//        map_params.put("startDate", "1633798800000");
//        map_params.put("endDate", "1734144399000");
        /* Tiếng Việt */
    }

    @Test
    public void allValid() throws JsonProcessingException {

        Request.send_validate(_url, _method, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, null);
    }
}
