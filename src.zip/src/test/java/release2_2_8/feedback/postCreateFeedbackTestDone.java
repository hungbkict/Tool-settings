package release2_2_8.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TextHelper;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class postCreateFeedbackTestDone {
    public String _url = Constants.URL_APP_BE + "/feedback";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "{\n" +
            "  \"content\": \"Hung to verify 30274413\",\n" +
            "  \"evidences\": [\n" +
            "    \"5215f4e0-fbbb-4c81-b153-60fd8a165dcc\"\n" +
            "  ],\n" +
            "  \"status\": \"NEW\",\n" +
            "  \"title\": \"Hung to verify " + TextHelper.randomString(50) + "\",\n" +
            "  \"type\": \"INCIDENT\"\n" +
            "}";


    @BeforeMethod
    public void init() {
        json_input_valid = "{\n" +
                "  \"content\": \"Hung to verify 30274413\",\n" +
                "  \"evidences\": [\n" +
                "    \"5215f4e0-fbbb-4c81-b153-60fd8a165dcc\"\n" +
                "  ],\n" +
                "  \"status\": \"NEW\",\n" +
                "  \"title\": \"Hung to verify " + TextHelper.randomString(50) + "\",\n" +
                "  \"type\": \"INCIDENT\"\n" +
                "}";
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }


    @Test(dataProvider = "methods")
    public void invalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, new String[]{"code", "message", "error"}, Constants.VALIDATE_BODY_RES_YES);
    }


    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test
    public void batch() throws JsonProcessingException {
        JSONObject json_input = new JSONObject(json_input_valid.toString());
        for (int i = 0; i < 10; i++) {
            String title = TextHelper.randomString(20);
//            String title = TextHelper.randomSentence();
            json_input.put("title", title);
            json_input.put("title", title);
            Request.send_validate(_url, _method, _token
                    , json_input.toString(), Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
        }

    }

    @DataProvider(name = "invalidTitle")
    public Object[][] invalTitle() {
        return new Object[][]{
                {null, 400, new String[]{"code", "message", "error"}},
                {"", 400, new String[]{"code", "message", "error"}},
                {"       ", 400, new String[]{"code", "message", "error"}},
                {"<h1>Test</h1>", 400, new String[]{"code", "message", "error"}},
                {"<script>alert('a')</script>", 400, new String[]{"code", "message", "error"}},
        };
    }

    @Test(enabled = true, dataProvider = "invalidTitle")
    public void validateFieldTitle(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "title";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }


    @DataProvider(name = "invalidContent")
    public Object[][] invalContent() {
        return new Object[][]{
                {null, 400, new String[]{"code", "message", "error"}},
                {"", 400, new String[]{"code", "message", "error"}},
                {"       ", 400, new String[]{"code", "message", "error"}},
                {"<h1>Test</h1>", 200, new String[]{"code", "data"}},
                {"<script>alert('a')</script>", 200, new String[]{"code", "data"}},
        };
    }

    @Test(enabled = true, dataProvider = "invalidContent")
    public void validateFieldContent(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "content";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }

    @DataProvider(name = "invalidStatusTypes")
    public Object[][] invalDataStatusTypes() {
        return new Object[][]{
                {null, 200, new String[]{"code", "data"}},
                {"", 400, new String[]{"code", "message", "error"}},
                {"       ", 400, new String[]{"code", "message", "error"}},
                {"<h1>Test</h1>", 400, new String[]{"code", "message", "error"}},
                {"<script>alert('a')</script>", 400, new String[]{"code", "message", "error"}},
        };
    }

    @Test(enabled = true, dataProvider = "invalidStatusTypes")
    public void validateFieldstatus(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "status";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }

    @Test(enabled = true, dataProvider = "invalidStatusTypes")
    public void validateFieldtype(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "type";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }

    @Test
    public void noAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}