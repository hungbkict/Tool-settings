package release2_2_8.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class postResponseFeedbackTestDone {
    public String _url = Constants.URL_APP_BE + "/feedback/a429cc29-d6c2-437c-8007-b1b74ac7cd28/response";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "{\n" +
            "  \"content\": \"Thai response11\",\n" +
            "  \"status\": \"IN_PROGRESS\",\n" +
            "  \"type\": \"INCIDENT\"\n" +
            "}";


    @DataProvider(name = "invalidValues")
    public Object[][] invalData() {
        return new Object[][]{
                {null, 400},
                {"", 400},
                {"       ", 400},
                {"<h1>Test</h1>", 400},
                {"<script>alert('a')</script>", 400},
        };
    }


    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token, json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405
                , new String[]{"code", "message", "error", "errors"}, Constants.VALIDATE_BODY_RES_YES);
    }

    @Test
    public void noAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }

    @DataProvider(name = "roles")
    public Object[][] rolesDP() {
        return new Object[][]{
                {Constants.TOKEN_ROOT, Constants.STATUS_CODE_4004009, new String[]{"code", "message", "error"}},
                {Constants.TOKEN_SYS_MANAGEMENT, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS},
                {Constants.TOKEN_OFFICE_MANAGER, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS},
                {Constants.TOKEN_STAFF, Constants.STATUS_CODE_4004009, new String[]{"code", "message", "error"}},
        };
    }

    @Test(dataProvider = "roles")
    public void authorize(String roleToken, Integer resCode, String[] res_keys) throws JsonProcessingException {
        Request.send_validate(_url, _method, roleToken
                , json_input_valid, Constants.MAP_PARAMS_NULL, resCode, res_keys, Constants.VALIDATE_BODY_RES_YES);
    }
}