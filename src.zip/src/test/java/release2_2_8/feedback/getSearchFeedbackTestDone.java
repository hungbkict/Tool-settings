package release2_2_8.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getSearchFeedbackTestDone {

    public String _url = Constants.URL_APP_BE + "/feedback/search";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};


    @BeforeMethod
    public void init() {
        map_params.put("page", 1);
        map_params.put("limit", 25);
//        map_params.put("keyword", "variations");
//        map_params.put("status", "COMPLETED");
//        map_params.put("userId", "0dd1b763-71b5-4057-bfb2-eb284075f01a");
//        map_params.put("types", "OTHER");
//        map_params.put("deviceIds", "c9a9a8d7-8bd6-484f-a395-1e13b9122e74");
//        map_params.put("startDate", "1633798800000");
//        map_params.put("endDate", "1734144399000");
    }

    @Test
    public void allValid() throws JsonProcessingException {

        Request.send_validate(_url, _method, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, null);
    }


    @DataProvider(name = "roles")
    public Object[][] rolesDP() {
        return new Object[][]{
                {Constants.TOKEN_ROOT, Constants.STATUS_CODE_200},
                {Constants.TOKEN_SYS_MANAGEMENT, Constants.STATUS_CODE_200},
                {Constants.TOKEN_OFFICE_MANAGER, Constants.STATUS_CODE_200},
                {Constants.TOKEN_STAFF, Constants.STATUS_CODE_200},
        };
    }

    @Test(dataProvider = "roles")
    public void authorize(String roleToken, Integer resCode) throws JsonProcessingException {
        Request.send_validate(_url, _method, roleToken
                , json_input_valid, map_params, resCode, new String[]{"code", "data"});
    }
}
