package release2_2_8.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TextHelper;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getFeedbackDetailTestDone {

    public String _url = Constants.URL_APP_BE + "/feedback/a429cc29-d6c2-437c-8007-b1b74ac7cd28/detail";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @BeforeMethod
    public void init() {
        String new_created_id = new_created_id();
        _url = Constants.URL_APP_BE + "/feedback/" + new_created_id + "/detail";
    }

    public String new_created_id() {
        String json_input_valid_create = "{\n" +
                "  \"content\": \"Hung to verify 30274413\",\n" +
                "  \"evidences\": [\n" +
                "    \"5215f4e0-fbbb-4c81-b153-60fd8a165dcc\"\n" +
                "  ],\n" +
                "  \"status\": \"NEW\",\n" +
                "  \"title\": \"Hung to verify " + TextHelper.randomString(50) + "\",\n" +
                "  \"type\": \"INCIDENT\"\n" +
                "}";


        JSONObject create_res = Request.send_get_data(Constants.URL_APP_BE + "/feedback", Constants.METHOD_POST, _token, json_input_valid_create, Constants.MAP_PARAMS_NULL);
        JSONObject create_date = (JSONObject) create_res.get("data");
        String created_id = create_date.getString("id");
        return created_id;
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
//                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, null);
    }
}
