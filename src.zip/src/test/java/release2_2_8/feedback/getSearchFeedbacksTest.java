package release2_2_8.feedback;

import libraries.Constants;
import libraries.Request;
import libraries.helper.TimeHelper;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getSearchFeedbacksTest {

    public String _url = Constants.URL_APP_BE + "/feedback/search";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ADMIN;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @Test
    public void allValid() {
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }


    @Test
    public void lowRoleAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF,
                json_input_valid, map_params, Constants.STATUS_CODE_401, null);
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, null);
    }

    @Test
    public void validateQuerieKeyword() {
        map_params.put("keyword", "keyword");
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieLimit() {
        map_params.put("limit", 50);
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQueriePage() {
        map_params.put("page", 1);
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieSort() {
        map_params.put("sort", "sort"); //TODO Change
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieStatus() {
        map_params.put("status", "status"); //TODO Change Available values : IN_PROGRESS, COMPLETED, NEW
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieTypes() {
        map_params.put("types", "types"); //TODO Change Available values : INCIDENT, EVENT, REPORT, OTHER
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieUserId() {
        map_params.put("userId", "userId"); //TODO Change $uuid
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieTime() {
        map_params.put("endDate", TimeHelper.timeNow());
        map_params.put("startDate", TimeHelper.timeLessOneWeek());
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }
}
