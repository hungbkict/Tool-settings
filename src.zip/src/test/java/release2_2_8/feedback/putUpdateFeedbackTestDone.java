package release2_2_8.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TextHelper;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class putUpdateFeedbackTestDone {
    public String _url = Constants.URL_APP_BE + "/feedback";
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "{\n" +
            "  \"content\": \"putUpdateFeedbackTest\",\n" +
            "  \"evidences\": [\n" +
            "    \"5215f4e0-fbbb-4c81-b153-60fd8a165d2b\"\n" +
            "  ],\n" +
            "  \"id\": \"af2310a6-01b4-4c25-9f67-ebde990cfe93\",\n" +
            "  \"deleted\": false,\n" +
            "  \"status\": \"NEW\",\n" +
            "  \"title\": \"putUpdateFeedbackTest\",\n" +
            "  \"type\": \"INCIDENT\"\n" +
            "}";


    @BeforeMethod
    public void init() {
        String new_created_id = new_created_id();
        json_input_valid = "{\n" +
                "  \"content\": \"putUpdateFeedbackTest\",\n" +
                "  \"evidences\": [\n" +
                "    \"5215f4e0-fbbb-4c81-b153-60fd8a165d2b\"\n" +
                "  ],\n" +
                "  \"id\": \"" + new_created_id + "\",\n" +
                "  \"deleted\": false,\n" +
                "  \"status\": \"NEW\",\n" +
                "  \"title\": \"putUpdateFeedbackTest\",\n" +
                "  \"type\": \"INCIDENT\"\n" +
                "}";
    }

    public String new_created_id() {
        String json_input_valid_create = "{\n" +
                "  \"content\": \"Hung to verify 30274413\",\n" +
                "  \"evidences\": [\n" +
                "    \"5215f4e0-fbbb-4c81-b153-60fd8a165dcc\"\n" +
                "  ],\n" +
                "  \"status\": \"NEW\",\n" +
                "  \"title\": \"Hung to verify " + TextHelper.randomString(50) + "\",\n" +
                "  \"type\": \"INCIDENT\"\n" +
                "}";


        JSONObject create_res = Request.send_get_data(Constants.URL_APP_BE + "/feedback", Constants.METHOD_POST, _token, json_input_valid_create, Constants.MAP_PARAMS_NULL);
        JSONObject create_date = (JSONObject) create_res.get("data");
        String created_id = create_date.getString("id");
        return created_id;
    }

    @DataProvider(name = "invalidValues")
    public Object[][] invalData() {
        return new Object[][]{
                {null, 400},
                {"", 400},
                {"       ", 400},
                {"<h1>Test</h1>", 400},
                {"<script>alert('a')</script>", 400},
        };
    }


    @Test
    public void allValid() throws JsonProcessingException {

        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @DataProvider(name = "invalidTitle")
    public Object[][] invalTitle() {
        return new Object[][]{
                {null, 400, new String[]{"code", "message", "error"}},
                {"", 400, new String[]{"code", "message", "error"}},
                {"       ", 400, new String[]{"code", "message", "error"}},
                {"<h1>Test</h1>", 400, new String[]{"code", "message", "error"}},
                {"<script>alert('a')</script>", 400, new String[]{"code", "message", "error"}},
        };
    }

    @Test(enabled = true, dataProvider = "invalidTitle")
    public void validateFieldTitle(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "title";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }


    @DataProvider(name = "invalidContent")
    public Object[][] invalContent() {
        return new Object[][]{
                {null, 400, new String[]{"code", "message", "error"}},
                {"", 400, new String[]{"code", "message", "error"}},
                {"       ", 400, new String[]{"code", "message", "error"}},
                {"<h1>Test</h1>", 200, new String[]{"code", "data"}},
                {"<script>alert('a')</script>", 200, new String[]{"code", "data"}},
        };
    }

    @Test(enabled = true, dataProvider = "invalidContent")
    public void validateFieldContent(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "content";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }

    @DataProvider(name = "invalidStatusTypes")
    public Object[][] invalDataStatusTypes() {
        return new Object[][]{
                {null, 200, new String[]{"code", "data"}},
                {"", 400, new String[]{"code", "message", "error"}},
                {"       ", 400, new String[]{"code", "message", "error"}},
                {"<h1>Test</h1>", 400, new String[]{"code", "message", "error"}},
                {"<script>alert('a')</script>", 400, new String[]{"code", "message", "error"}},
        };
    }

    @Test(enabled = true, dataProvider = "invalidStatusTypes")
    public void validateFieldstatus(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "status";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }

    @Test(enabled = true, dataProvider = "invalidStatusTypes")
    public void validateFieldtype(String inValid, int returnCode, String[] keys) {
//        String[] keys = {"title","content","status","type"};
        String k = "type";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }


    @Test
    public void noAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}