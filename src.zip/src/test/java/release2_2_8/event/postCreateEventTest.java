package release2_2_8.event;

import libraries.Constants;
import libraries.Request;
import libraries.helper.TimeHelper;
import org.testng.annotations.Test;

public class postCreateEventTest {
    public String _url = Constants.URL_AC + "/events";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_AC;
    public String json_input_valid = "{\n" +
            "  \"accessType\": \"IN\",\n" +
            "  \"deviceId\": \"beb50376-1e59-4357-bd4e-ac491f267b09\",\n" +
            "  \"eventAt\": " + TimeHelper.timeNow() + ",\n" +
            "  \"eventCategoryCode\": \"NORMAL_FACE_OPENING\",\n" +
            "  \"userId\": \"9c260a99-4105-43ef-928a-670ff9016784\"" +
            "}";

    @Test
    public void allValid() {
        String[] guests = new String[]{
//                "26d63608-b53c-4e5e-9aab-daf058b2b7a7",
//                "9c260a99-4105-43ef-928a-670ff9016784",
//                "82bb718f-4eab-4851-baff-49078d659e4a",
//                "52a4d94e-3cd1-43a5-9ab0-1e638723c686",
//                "94cd8006-a32a-4335-a108-2170ed8faede",
                "36b8d0d0-893a-4d7b-bd76-07585a7651db",
        };
//        for (int i = 0; i < 5; i++) {
        for (String gu : guests) {
            json_input_valid = "{\n" +
                    "  \"accessType\": \"IN\",\n" +
//                    "  \"accessType\": \"OUT\",\n" +
                    "  \"deviceId\": \"404199c6-904b-453f-b2f4-9f3d8e6bab85\",\n" +
                    "  \"eventAt\": " + TimeHelper.timeNow() + ",\n" +
                    "  \"eventCategoryCode\": \"NORMAL_FACE_OPENING\",\n" +
                    "  \"userId\": \"" + gu + "\"" +
                    "}";

            Request.send_validate(_url, _method, _token
                    , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
        }

    }

}