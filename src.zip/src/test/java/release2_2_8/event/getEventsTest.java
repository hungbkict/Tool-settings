package release2_2_8.event;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import libraries.helper.LogsHelper;
import libraries.helper.TimeHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class getEventsTest {

    public String _url = Constants.URL_AC + "/events";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String , Object > map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};

    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
//                {Constants.METHOD_GET},
//                {Constants.METHOD_POST}, Method này có API khác
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        map_params.put("isGuest", true);
        map_params.put("companyIds", "918672de-df24-498a-9f5a-c63ba830db98&companyIds=bb97c369-2826-4249-8cd2-b08040fc4739");
        map_params.put("startDate", "1634490000000");
        map_params.put("endDate", "1634835599000");
        Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};

//        JSONObject json_data = new JSONObject(json_res.get("data"));
//        JSONArray json_data_rows = json_res.getJSONObject("data").getJSONArray("rows");
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
//        Assert.assertTrue(json_data_rows.length()==25);
        res.then().statusCode(200);
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        map_params.put("isGuest", true);
        map_params.put("companyIds", "918672de-df24-498a-9f5a-c63ba830db98&companyIds=bb97c369-2826-4249-8cd2-b08040fc4739");
        map_params.put("startDate", "1634490000000");
        map_params.put("endDate", "1634835599000");
        Response res = Request.send(_url, met, _token
                , json_input_valid, map_params);
        System.out.println("response: "+res);
        res.prettyPrint();
//        JSONObject json_res = new JSONObject(res.asString());
//        String[] keys = {"code","data"};
//        JsonMinh.jsonlackKeys(keys, json_res);
//        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(405);

    }

    @Test
    public void getTimeDiff() throws IOException {


        map_params.put("limit", 25);
//        map_params.put("isGuest", false);

//        map_params.put("startDate", 1652288400000L);
//        map_params.put("endDate", 1652374740000L);
        map_params.put("startDate", TimeHelper.timeNow()-86400000*120);
        map_params.put("endDate", TimeHelper.timeNow());

        int total_page = 3151;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        for (int i = 1; i < total_page; i++) {
            map_params.put("page", i);
            Response res = Request.send(_url, _method, Constants.TOKEN_REAL
                    , json_input_valid, map_params);
//            LogsHelper.console(res);

//            JSONObject res_all = new JSONObject(res.asString());
//            JSONObject data_all = (JSONObject) res_all.getJSONObject("data");
//            JSONArray res_data = data_all.getJSONArray("rows");
//
//            for (int ai = 0; ai < res_data.length(); ai++) {
//                JSONObject data = (JSONObject) res_data.get(ai);
//                Long dif = data.getLong("createdAt") - data.getLong("eventAt");
//                if (dif > 180000) {
//                    dif = dif/60000;
//                    Long hour = dif/60;
//                    Date date = new Date(data.getLong("eventAt"));
//                    String eventAt = dateFormat.format(date);
//                    String txt = "User " + data.getString("userName") + " eventAt: " +eventAt + "   diff:  " + dif.toString()+ " mins = "+ hour.toString()+" hours";
//
//                    System.out.println(txt);
//                    LogsHelper.write_to_file(this.getClass().getName(),"log", txt, true);
//                }
//            }
        }
    }

    @Test
    public void getTimeDiffSingle() throws IOException {

        String duybg = "be978118-f852-4e65-85d0-e5faa4a6672b";
        String thoai = "f7b86570-848d-4928-b30f-648a9c63ff57";
        String giang = "601c05d4-d885-4b52-8610-7e7b45d5951b";
        String hungnk = "36b8d0d0-893a-4d7b-bd76-07585a7651db";
        map_params.put("limit", 100);
        map_params.put("isGuest", false);
        map_params.put("userIds", giang);

//        map_params.put("startDate", 1652288400000L);
//        map_params.put("endDate", 1652374740000L);
//        map_params.put("startDate", 1652288400000L);
//        map_params.put("endDate", 1652374740000L);
        map_params.put("startDate", TimeHelper.timeNow()-86400000*120);
        map_params.put("endDate", TimeHelper.timeNow());
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        map_params.put("page", 1);
        Response res = Request.send(_url, _method, Constants.TOKEN_REAL
                , json_input_valid, map_params);
            LogsHelper.console(res);

        JSONObject res_all = new JSONObject(res.asString());
        JSONObject data_all = (JSONObject) res_all.getJSONObject("data");
        JSONArray res_data = data_all.getJSONArray("rows");

        for (int ai = 0; ai < res_data.length(); ai++) {
            JSONObject data = (JSONObject) res_data.get(ai);
            Long dif = data.getLong("createdAt") - data.getLong("eventAt");
//            if (dif > 60000) {
                dif = dif/60000;
                Long hour = dif/60;
                Date date = new Date(data.getLong("eventAt"));
                String eventAt = dateFormat.format(date);
                String txt = "User " + data.getString("userName") + " eventAt: " +eventAt + "Type: " + data.getString("accessType") + "Device: " + data.getString("deviceName")+ "   diff:  " + dif.toString()+ " mins = "+ hour.toString()+" hours";

                System.out.println(txt);
                LogsHelper.write_to_file(this.getClass().getName(),"log", txt, true);
//            }
        }
    }
}
