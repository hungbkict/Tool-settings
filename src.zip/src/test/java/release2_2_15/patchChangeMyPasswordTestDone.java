package release2_2_15;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Prepare;
import libraries.Request;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class patchChangeMyPasswordTestDone {

    public String _url = Constants.URL_IAM + "/me/password";
    public String _method = Constants.METHOD_PATCH;
    public String _token = Constants.TOKEN_PROD_HUNGNK;
    public String json_input_valid = "{\n" +
//            "  \"currentPassword\": \"Vsm1234@213\",\n" +
//            "  \"newPassword\": \"Vsm1234@\"\n" +
            "  \"currentPassword\": \"Vsm1234@\",\n" +
            "  \"newPassword\": \"Vsm1234@213   \"\n" +
            "}";


    @BeforeMethod
    public void init() {
    }

//    @DataProvider(name = "invalidValues")
//    public Object[][] invalData() {
//        return new Object[][]{
//                {null, 400},
//                {"", 400},
//                {"       ", 400},
//                {"<h1>Test</h1>", 400},
//                {"<script>alert('a')</script>", 400},
//        };
//    }


    @Test
    public void allValid() throws JsonProcessingException {
        Prepare.getTokenCognito("hungnk_1636014361571","Vsm1234@");
//        Request.send_validate(_url, _method, _token
//                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"access_token", "refresh_token", "expires_in", "token_type"});
    }

    @Test
    public void noAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY,
                json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }

    @Test
    public void expiredToken() throws JsonProcessingException {
        String old_token = Prepare.getTokenCognitoExpired("hungnk_1638507626328","Vsm1234@213");
        json_input_valid = "{\n" +
//            "  \"currentPassword\": \"Vsm1234@213\",\n" +
//            "  \"newPassword\": \"Vsm1234@\"\n" +
                "  \"currentPassword\": \"Vsm1234@\",\n" +
                "  \"newPassword\": \"Vsm1234@213\"\n" +
                "}";
//        Response res=  Request.send(_url, _method, Constants.TOKEN_REAL+old_token,json_input_valid, Constants.MAP_PARAMS_NULL);
//
//        LogsHelper.console(res);
        Request.send_validate(_url, _method, Constants.TOKEN_REAL+old_token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"access_token", "refresh_token", "expires_in", "token_type"});
    }
}