package release2_2_15;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class putEnableUserTestDone {

    public String _url = Constants.URL_IAM + "/users/7cec0b52-7ad6-4c03-bf27-d70e48ed1d42/enable";
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";

    Map<String, Object> map_params = new HashMap<>();

    @BeforeMethod
    public void init() {
    }

//    @DataProvider(name = "invalidValues")
//    public Object[][] invalData() {
//        return new Object[][]{
//                {null, 400},
//                {"", 400},
//                {"       ", 400},
//                {"<h1>Test</h1>", 400},
//                {"<script>alert('a')</script>", 400},
//        };
//    }

    //NOTE không validate giá trị enabled

    @Test
    public void allValid() throws JsonProcessingException {
        map_params.put("enabled", true);
        for (int i = 0; i < 2; i++) {
            Request.send_validate(_url, _method, _token
                    , json_input_valid, map_params, Constants.STATUS_CODE_200, null);
        }

    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void invalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, null);
    }

    @Test
    public void noAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY,
                json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}