package release2_2_15;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TextHelper;
import libraries.helper.TimeHelper;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class postCreateUserTestDone {
    public String _url = Constants.URL_IAM + "/users";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "    \"default\": true,\n" +
            "    \"username\": \"hungnk3\",\n" +
            "    \"email\": \"hungnk3@mail.com\",\n" +
            "    \"password\": \"Vsm1234@\",\n" +
            "    \"employeeCode\": \"22151\",\n" +
            "    \"fullName\": \"hungnk3\",\n" +
            "    \"leader\": false,\n" +
            "    \"mobile\": \"0896541237\",\n" +
            "    \"orgUnitId\": \"bb97c369-2826-4249-8cd2-b08040fc4739\",\n" +
            "    \"positionId\": null,\n" +
            "    \"status\": \"ACTIVE\",\n" +
            "    \"units\": [],\n" +
            "    \"userId\": \"aa675d75-13e1-43e9-9c45-b08e106f1ac0\",\n" +
            "    \"vehicles\": [],\n" +
            "    \"workPhone\": null,\n" +
            "    \"workPhoneExt\": null,\n" +
            "    \"policyIds\": [],\n" +
            "    \"groupId\": null,\n" +
            "    \"availableAt\": " + TimeHelper.timeNow() + ",\n" +
            "    \"expiredAt\": " + TimeHelper.timeMoreOneWeek() + "\n" +
            "}";
    String std_json_input_json = "{\n" +
            "  \"availableAt\": \"2021-11-04T04:37:12.182Z\",\n" +
            "  \"default\": true,\n" +
            "  \"email\": \"string\",\n" +
            "  \"employeeCode\": \"string\",\n" +
            "  \"expiredAt\": \"2021-11-04T04:37:12.182Z\",\n" +
            "  \"fullName\": \"string\",\n" +
            "  \"leader\": true,\n" +
            "  \"mobile\": \"string\",\n" +
            "  \"orgUnitId\": \"string\",\n" +
            "  \"password\": \"string\",\n" +
            "  \"policyIds\": [\n" +
            "    \"string\"\n" +
            "  ],\n" +
            "  \"positionId\": 0,\n" +
            "  \"status\": \"ACTIVE\",\n" +
            "  \"units\": [\n" +
            "    {\n" +
            "      \"leader\": true,\n" +
            "      \"orgUnitId\": \"string\",\n" +
            "      \"positionId\": 0\n" +
            "    }\n" +
            "  ],\n" +
            "  \"username\": \"string\",\n" +
            "  \"vehicles\": [\n" +
            "    {\n" +
            "      \"cardNumber\": \"string\",\n" +
            "      \"id\": \"string\",\n" +
            "      \"name\": \"string\",\n" +
            "      \"plateNumber\": \"string\",\n" +
            "      \"status\": \"ACTIVE\",\n" +
            "      \"vehicleType\": \"string\"\n" +
            "    }\n" +
            "  ],\n" +
            "  \"workPhone\": \"string\",\n" +
            "  \"workPhoneExt\": \"string\"\n" +
            "}";
    @BeforeMethod
    public void init() {
        String uname = "hungnk_"+TimeHelper.timeNow();
//        String uname = "hungbkict1";
//        String uname = "hungbkict1";
        json_input_valid = "{\n" +
                "    \"default\": true,\n" +
                "    \"username\": \""+uname+"\",\n" +
                "    \"email\": \""+uname+"@gmail.com\",\n" +
//                "    \"email\": \"hungbkict@gmail.com\",\n" +
                "    \"password\": \"Vsm1234@\",\n" +
                "    \"employeeCode\": \""+TextHelper.randomInt(111111,999999)+"\",\n" +
                "    \"fullName\": \""+uname+"\",\n" +
                "    \"leader\": false,\n" +
                "    \"mobile\": \"09"+TextHelper.randomInt(1111111,9999999)+"\",\n" +
                "    \"orgUnitId\": \"bb97c369-2826-4249-8cd2-b08040fc4739\",\n" +
                "    \"positionId\": null,\n" +
                "    \"status\": \"ACTIVE\",\n" +
                "    \"units\": [],\n" +
                "    \"vehicles\": [],\n" +
                "    \"workPhone\": null,\n" +
                "    \"workPhoneExt\": null,\n" +
                "    \"policyIds\": [],\n" +
                "    \"groupId\": null,\n" +
                "    \"availableAt\": " + TimeHelper.timeNow() + ",\n" +
                "    \"expiredAt\": " + TimeHelper.timeMoreOneWeek() + "\n" +
                "}";
    }

    @Test(priority = 1)
    @Severity(SeverityLevel.BLOCKER)
    @Description("allValid")
    public void allValid() throws JsonProcessingException {
//        JsonMinh.jsonCompare("root", new JSONObject(json_input_valid), new JSONObject(std_json_input_json));
//        System.out.println(json_input_valid);
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_201, Constants.DEFAULT_RESPONSE_KEYS);

    }


    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(priority = 2, dataProvider = "methods")
    @Severity(SeverityLevel.BLOCKER)
    @Description("invalidMethods")
    public void invalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, new String[]{"code", "message", "error"}, Constants.VALIDATE_BODY_RES_YES);
    }

    @Test(priority = 3)
    @Severity(SeverityLevel.CRITICAL)
    @Description("lowRoleCheck")
    public void lowRoleCheck() {
        String[] lowTokens = new String[]{Constants.TOKEN_OFFICE_MANAGER, Constants.TOKEN_STAFF};
        for (String tkn: lowTokens) {
            Request.send_validate(_url, _method, tkn
                    , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
        }

    }


    @DataProvider(name = "invalidUsername")
    public Object[][] invalidUsername() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomInt(1111,9999)+"   ", 201, new String[]{"code", "data"}, false},
                {"<h1>"+TextHelper.randomInt(1111,9999)+"</h1>", 400, new String[]{"code", "message", "error"}, false},
                {"<script>alert('"+TextHelper.randomString(50)+"a')</script>", 400, new String[]{"code", "message", "error"}, false},
                {"qa.hungnk2@gmail.com", 4090004, new String[]{"code", "message", "error"}, true},
                {"hungnk4", 4090004, new String[]{"code", "message", "error"}, true},
        };
    }

    @Test(priority = 4, enabled = true, dataProvider = "invalidUsername")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldUsername")
    public void validateFieldUsername(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "username";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys, checkBodyCode);
    }


    @DataProvider(name = "invalidUserCode")
    public Object[][] invalidUserCode() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomInt(11111,99999)+"   ", 201, new String[]{"code", "data"}, false},
                {"LongCode50_"+TextHelper.randomString(50),  400, new String[]{"code", "message", "error"}, false},
                {"<h1>"+TextHelper.randomInt(1111,9999)+"</h1>", 400, new String[]{"code", "message", "error"}, false},
                {"<script>alert('"+TextHelper.randomString(50)+"a')</script>", 400, new String[]{"code", "message", "error"}, false},
                {"809826", 4090004, new String[]{"code", "message", "error"}, true},
        };
    }

    @Test(priority = 5, enabled = true, dataProvider = "invalidUserCode")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldCUserCode")
    public void validateFieldCUserCode(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "employeeCode";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys);
    }


    @DataProvider(name = "invalidEmail")
    public Object[][] invalidEmail() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomInt(1111,9999)+"@gmail.com  ", 201, new String[]{"code", "data"}, false},
                {"<h1>"+TextHelper.randomInt(1111,9999)+"</h1>@gmail.com", 400, new String[]{"code", "message", "error"}, false},
                {"<script>"+TextHelper.randomString(50)+"('a')</script>@gmail.com", 400, new String[]{"code", "message", "error"}, false},
                {"existed_mail@gmail.com", 4090007, new String[]{"code", "message", "error"}, true},
        };
    }

    @Test(priority = 6, enabled = true, dataProvider = "invalidEmail")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldEmail")
    public void validateFieldEmail(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "email";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys, checkBodyCode);
    }

    @DataProvider(name = "invalidStatus")
    public Object[][] invalidStatus() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"Email_Dai_Oi_la_dai_Dai_Oi_la_dai_Dai_Oi_la_dai_Dai_Oi_la_dai"+TextHelper.randomInt(1111,9999)+"@gmail.com  ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomInt(1111,9999)+"@gmail.com  ", 400, new String[]{"code", "message", "error"}, false},
                {"<h1>"+TextHelper.randomInt(1111,9999)+"</h1>@gmail.com", 400, new String[]{"code", "message", "error"}, false},
                {"<script>"+TextHelper.randomString(50)+"('a')</script>@gmail.com", 400, new String[]{"code", "message", "error"}, false},
                {"DEACTIVE",  400, new String[]{"code", "message", "error"}, false},
        };
    }

    @Test(priority = 7, enabled = true, dataProvider = "invalidStatus")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldStatus")
    public void validateFieldStatus(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "status";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys, checkBodyCode);
    }

    @DataProvider(name = "invalidOrg")
    public Object[][] invalidOrg() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomInt(1111,9999)+"@gmail.com  ", 400, new String[]{"code", "message", "error"}, false},
                {"<h1>"+TextHelper.randomInt(1111,9999)+"</h1>@gmail.com", 400, new String[]{"code", "message", "error"}, false},
                {"<script>"+TextHelper.randomString(50)+"('a')</script>@gmail.com", 400, new String[]{"code", "message", "error"}, false},
                {"bb97c369-2826-4249-8cd2-b08040",  400, new String[]{"code", "message", "error"}, false},
        };
    }

    @Test(priority = 8, enabled = true, dataProvider = "invalidOrg")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldOrg")
    public void validateFieldOrg(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "orgUnitId";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys, checkBodyCode);
    }

    @DataProvider(name = "invalidPW")
    public Object[][] invalidPW() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomString(10)+"  ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomString(2)+"  ", 400, new String[]{"code", "message", "error"}, false},
                {"    "+TextHelper.randomString(100)+"@  ", 400, new String[]{"code", "message", "error"}, false},
        };
    }

    @Test(priority = 9, enabled = true, dataProvider = "invalidPW")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldPW")
    public void validateFieldPW(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "password";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys, checkBodyCode);
    }


    @DataProvider(name = "invalidPhone")
    public Object[][] invalidPhone() {
        return new Object[][]{
                {"", 400, new String[]{"code", "message", "error"}, false},
                {"       ", 400, new String[]{"code", "message", "error"}, false},
                {"    080000"+TextHelper.randomInt(1111,9999)+"  ", 400, new String[]{"code", "message", "error"}, false},
                {"    Wrong format"+TextHelper.randomString(10)+"  ", 400, new String[]{"code", "message", "error"}, false},
        };
    }

    @Test(priority = 10, enabled = true, dataProvider = "invalidPhone")
    @Severity(SeverityLevel.CRITICAL)
    @Description("validateFieldPhone")
    public void validateFieldPhone(String inValid, int returnCode, String[] keys, Boolean checkBodyCode) {
        String k = "mobile";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, returnCode, keys, checkBodyCode);
    }




//    @Test(priority = 8)
//    @Severity(SeverityLevel.CRITICAL)
//    @Description("PasswordContainSpaces")
//    public void PasswordContainSpaces() {
//        JSONObject json_input = new JSONObject(json_input_valid);
//        json_input.put("password", 1);
//        Request.send_validate(_url, _method, _token
//                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
//
//    }

    @Test
    public void noAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}