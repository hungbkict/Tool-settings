package release2_2_15;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class postForgotPasswordTestDone {
    public String _url = Constants.URL_IAM + "/me/forgot-password";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_PROD_HUNGNK;
    public String json_input_valid = "{\n" +
            "  \"email\": \"hungbkict@gmail.com\"\n" +
            "}";

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_PATCH},
                {Constants.METHOD_PUT},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void invalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, new String[]{"code", "message", "error"}, Constants.VALIDATE_BODY_RES_YES);
    }

    //TODO DONE mai check lại valid email vẫn trả lại 400
    //TODO DONE Thử email hungbkict ngon xem có nhận được email không

    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test
    public void noAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, null);

    }
}