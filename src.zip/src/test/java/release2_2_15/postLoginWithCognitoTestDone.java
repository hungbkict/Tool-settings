package release2_2_15;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.dzieciou.testing.curl.CurlRestAssuredConfigFactory;
import com.github.dzieciou.testing.curl.Options;
import com.github.dzieciou.testing.curl.Platform;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import model.User;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class postLoginWithCognitoTestDone {
    public String _url = Constants.URL_IAM + "/login-with-cognito";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "{\n" +
            "  \"username\": \"hungnk_1636011681677\",\n" +
            "  \"password\": \"Vsm1234@213     \"\n" +
            "}";


    @BeforeMethod
    public void init() {
//        json_input_valid = "{\n" +
//                "  \"content\": \"Hung to verify 30274413\",\n" +
//                "  \"evidences\": [\n" +
//                "    \"5215f4e0-fbbb-4c81-b153-60fd8a165dcc\"\n" +
//                "  ],\n" +
//                "  \"status\": \"NEW\",\n" +
//                "  \"title\": \"Hung to verify " + TextHelper.randomString(50) + "\",\n" +
//                "  \"type\": \"INCIDENT\"\n" +
//                "}";
    }


    public Response postLogin() {
        Options options = Options
                .builder()
                .printMultiliner()
                .targetPlatform(Platform.UNIX)  //để không nháy đôi giá kí tự "" trong data-binary
                .useLongForm() //để hiện --header thay vì -H
                .build();
        RestAssuredConfig config = CurlRestAssuredConfigFactory.createConfig(options);

        Response res = given()
                .log()
                .all()
//                .filter(new AllureRestAssured())
                .config(config)
                .contentType("application/json")
                .body(new User("hungnk_1636011681677", "Vsm1234@213"))
                .urlEncodingEnabled(false)
                .post("https://uat-technopark.vsmart.net/tnp/iam/api/v0/login-with-cognito");
        return res;
    }


    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_PUT},
                {Constants.METHOD_DELETE},
        };
    }
    @Test(dataProvider = "methods")
    public void invalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, new String[]{"code", "message", "error"}, Constants.VALIDATE_BODY_RES_YES);
    }


    @Test
    public void allValid() throws JsonProcessingException {
//        for (int i = 0; i < 10; i++) {
            Response res = postLogin();
            res.prettyPrint();
            res.then().statusCode(200);
//        }
    }

    @Test
    public void batch() throws JsonProcessingException {
        for (int i = 0; i < 10; i++) {
            Response res = postLogin();
            res.prettyPrint();
            res.then().statusCode(200);
        }

    }


    @Test
    public void noAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, null);
    }
}