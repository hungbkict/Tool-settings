package release2_2_11.ac;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getEventsTest {

    public String _url = Constants.URL_AC + "/events";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};


    @Test
    public void allValid() throws JsonProcessingException {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        map_params.put("userIds", "2a2f9bc1-e7c8-49c6-ba0c-a50504d0a9c9"); //Guest QUYNHLV
        map_params.put("isGuest", true);
//        map_params.put("page", 2);
//        map_params.put("deviceIds", "c9a9a8d7-8bd6-484f-a395-1e13b9122e74");
//        map_params.put("startDate", "1633798800000");
//        map_params.put("endDate", "1634144399000");
//        String[] keys = {"code","data"};
        Request.send_validate(_url, _method, _token, json_input_valid, map_params, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }


    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
//                {Constants.METHOD_GET},
//                {Constants.METHOD_POST}, Method này có API khác
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        map_params.put("startDate", "1633798800000");
        map_params.put("endDate", "1734144399000");
        Request.send_validate(_url, met, _token, json_input_valid, map_params, Constants.STATUS_CODE_405, new String[]{"code", "message"});
    }
}
