package release2_2_9.guest_reg;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getFindGuestByDateTest {

    public String _url = Constants.URL_GUEST + "/guests/find_guest-by-date";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String , Object > map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};

    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
//                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }
    @Test
    public void allValid() throws JsonProcessingException {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        map_params.put("registerDate", "1633798800000");
        map_params.put("status", "CANCELLED");  //Available values : NOT_ARRIVED, ARRIVED, CANCELLED
        Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
        res.prettyPrint();
        res.then().statusCode(200);
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
    }


    @Test
    public void lowRoleAuthen() throws JsonProcessingException {
//        map_params.put("page", 1);
//        map_params.put("limit", 25);
        Response res = Request.send(_url, _method, Constants.TOKEN_OFFICE_MANAGER
                , json_input_valid, map_params);
        res.prettyPrint();
        res.then().statusCode(200);
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
    }

    @Test
    public void spaceToken() throws JsonProcessingException {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        Response res = Request.send(_url, _method, Constants.TOKEN_USER_SPACE
                , json_input_valid, map_params);
        res.prettyPrint();
        res.then().statusCode(401);
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        Response res = Request.send(_url, met, _token
                , json_input_valid, map_params);
        System.out.println("response: "+res);
        res.prettyPrint();
        res.then().statusCode(405);
    }
}
