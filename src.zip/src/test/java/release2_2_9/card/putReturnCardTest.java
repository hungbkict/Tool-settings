package release2_2_9.card;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class putReturnCardTest {
    public String _url = Constants.URL_AC + "/cards/return-back";
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"cardIds\": [\n" +
            "    \"bfa8f125-6865-4ab1-9796-2686a4449155\"\n" +
            "  ]\n" +
            "}";


    @DataProvider(name="invalidValues")
    public Object[][] invalData(){
        return new Object[][] {
                {null,400},
                {"",400},
                {"       ",400},
                {"<h1>Test</h1>",400},
                {"<script>alert('a')</script>",400},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code"});
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldTitle(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "title";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldContent(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "content";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldstatus(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "status";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldtype(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "type";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test
    public void noAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}