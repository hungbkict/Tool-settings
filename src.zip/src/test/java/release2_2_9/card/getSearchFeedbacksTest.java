package release2_2_9.card;

import libraries.Constants;
import libraries.Request;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getSearchFeedbacksTest {

    public String _url = Constants.URL_APP_BE + "/feedback/search";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ADMIN;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @Test
    public void allValid() {
        Request.send_validate(_url, _method, _token, json_input_valid, Constants.MAP_PARAMS_NULL,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }


    @Test
    public void lowRoleAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}