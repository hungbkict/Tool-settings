package release2_2_9.card;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getCardStatisticTestDone {

    public String _url = Constants.URL_AC + "/cards/statistics";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void lowRoleAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_403, new String[]{"code", "message", "error"});
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_POST},
//                {Constants.METHOD_PUT},   //cards/{cardId}  Update card
                {Constants.METHOD_PATCH},
//                {Constants.METHOD_DELETE},  //cards/{cardId}   Delete card
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, null);
    }
}
