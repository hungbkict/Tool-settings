package release2_2_9.card;

import libraries.Constants;
import libraries.Request;
import libraries.helper.TimeHelper;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class __postCreateCardTest {
    public String _url = Constants.URL_AC + "/cards";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"availableAt\": " + TimeHelper.timeNow() + ",\n" +
            "  \"backCardNumber\": \"2128518522\",\n" +
            "  \"cardNumber\": \"2128518511\",\n" +
            "  \"cardStatus\": \"NEW\",\n" +
            "  \"cardType\": \"PROXIMITY\",\n" +
            "  \"cardUserType\": \"EMPLOYEE\",\n" +
            "  \"companyId\": \"e28d5c82-d59f-4161-905a-bb9828759fd6\",\n" +
            "  \"expiredAt\": " + TimeHelper.timeTomorrow() + ",\n" +
            "  \"frontCardNumber\": \"2128518533\"\n" +
            "}";


    @DataProvider(name="invalidValues")
    public Object[][] invalData(){
        return new Object[][] {
                {null,400},
                {"",400},
                {"       ",400},
                {"<h1>Test</h1>",400},
                {"<script>alert('a')</script>",400},
        };
    }

    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
                {Constants.METHOD_GET},
//                {Constants.METHOD_POST},
//                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, Constants.DEFAULT_RESPONSE_KEYS);
    }


    @Test
    public void allValid() {

        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }


    @Test
    public void batch() {
        JSONObject json_input = new JSONObject(json_input_valid.toString());
        for (int i = 0; i < 10; i++) {
            int cnum = 2128518511;
            int bnum = 2028518511;
            int fnum = 8511;
            cnum += i;
            String json_input_valid2 = "{\n" +
                    "  \"availableAt\": " + TimeHelper.timeNow() + ",\n" +
                    "  \"backCardNumber\": \"" + bnum + "\",\n" +
                    "  \"cardNumber\": \"" + cnum + "\",\n" +
                    "  \"cardStatus\": \"NEW\",\n" +
                    "  \"cardType\": \"PROXIMITY\",\n" +
                    "  \"cardUserType\": \"EMPLOYEE\",\n" +
                    "  \"companyId\": \"e28d5c82-d59f-4161-905a-bb9828759fd6\",\n" +
                    "  \"expiredAt\": " + TimeHelper.timeTomorrow() + ",\n" +
                    "  \"frontCardNumber\":\"" + fnum + "\",\n" +
                    "}";

            Request.send_validate(_url, _method, _token
                    , json_input_valid2.toString(), Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
        }

    }

    @Test(enabled = true, dataProvider = "invalidValues")
    public void validateFieldTitle(String inValid, int returnCode) {
        String k = "title";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test(enabled = true, dataProvider = "invalidValues")
    public void validateFieldContent(String inValid, int returnCode) {
        String k = "content";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test(enabled = true, dataProvider = "invalidValues")
    public void validateFieldstatus(String inValid, int returnCode) {
//        String[] keys = {"title","content","status","type"};
        String k = "status";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test(enabled = true, dataProvider = "invalidValues")
    public void validateFieldtype(String inValid, int returnCode) {
//        String[] keys = {"title","content","status","type"};
        String k = "type";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Request.send_validate(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test
    public void noAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, Constants.DEFAULT_RESPONSE_KEYS);
    }
}