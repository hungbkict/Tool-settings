package release2_2_9.card;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getListCardTestDone {

    public String _url = Constants.URL_AC + "/cards";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @BeforeMethod
    public void init() {
//        map_params.put("page", 1);
//        map_params.put("limit", 25);
        map_params.put("cardStatus", "ACTIVE");  // NEW, ACTIVE, INACTIVE
//        map_params.put("cardUserType", "GUEST");  // EMPLOYEE, GUEST
//        map_params.put("sort", "id&sort=createdAt");
//        map_params.put("keyword", "2128518511");
//        map_params.put("companyId", "");
//        map_params.put("startAt", "1633798800000");
//        map_params.put("endAt", "1733798800000");
    }


    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
//                {Constants.METHOD_GET},
//                {Constants.METHOD_POST}, // có method post de tao card
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }


    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }

    @Test
    public void allValidByDate() throws JsonProcessingException {

//        map_params.put("startAt", TimeHelper.timeLessOneMonth());
//        map_params.put("endAt", TimeHelper.timeNow());
        Request.send_validate(_url, _method, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }


    @Test
    public void lowRoleAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF
                , json_input_valid, map_params, Constants.STATUS_CODE_401, null);
    }

    @Test
    public void spaceToken() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_USER_SPACE
                , json_input_valid, map_params, Constants.STATUS_CODE_401, null);
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, new String[]{"code", "message", "error"});
    }
}
