package release2_2_9.card;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class deleteCardTestDone {

    public String _url = Constants.URL_AC + "/cards/d0d30c6c-dc59-4178-855f-7cbf5a3e2e60";
    public String _method = Constants.METHOD_DELETE;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code"});
    }


    @Test
    public void lowRoleAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code", "message", "error"});
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_POST},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
//      Không validate methods do các method khác có cài ?? tính năng khác
    }
}
