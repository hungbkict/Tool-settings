package release2_2_9.card;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import libraries.helper.TimeHelper;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class __putUpdateCardTest {
    public String _url = Constants.URL_AC + "/cards/b254e017-2a28-4636-9442-da5503aae0ab";
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "{\n" +
            "  \"availableAt\": " + TimeHelper.timeNow() + ",\n" +
            "  \"cardStatus\": \"ACTIVE\",\n" +
            "  \"expiredAt\": " + TimeHelper.timeTomorrow() + ",\n" +
            "  \"returnedAt\": " + TimeHelper.timeNow() + ",\n" +
            "  \"userId\": \"002a2bfd-7282-4a90-a81e-44ff2a02311a\"\n" +
            "}";
// public String json_input_valid = "{\n" +
//            "  \"availableAt\": \"2021-10-20T07:59:49.804Z\",\n" +
//            "  \"cardStatus\": \"ACTIVE\",\n" +
//            "  \"expiredAt\": \"2021-10-24T07:59:49.804Z\",\n" +
//            "  \"returnedAt\": \"2021-10-21T07:59:49.804Z\",\n" +
//            "  \"userId\": \"c41e3ece-6fe1-4dc4-9fa8-9e3cbad0ed23\"\n" +
//            "}";


    @DataProvider(name="invalidValues")
    public Object[][] invalData(){
        return new Object[][] {
                {null,400},
                {"",400},
                {"       ",400},
                {"<h1>Test</h1>",400},
                {"<script>alert('a')</script>",400},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldTitle(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "title";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldContent(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "content";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldstatus(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "status";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test(enabled=true, dataProvider = "invalidValues")
    public void validateFieldtype(String inValid, int returnCode) throws JsonProcessingException {
//        String[] keys = {"title","content","status","type"};
        String k = "type";
        JSONObject json_input = new JSONObject(json_input_valid);
        json_input.put(k, inValid);
        Response res = Request.send(_url, _method, _token
                , json_input.toString(), Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(returnCode);
    }

    @Test
    public void noAuthen() throws JsonProcessingException {
        Response res = Request.send(_url, _method, Constants.TOKEN_EMPTY
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        res.then().statusCode(200);
    }
}