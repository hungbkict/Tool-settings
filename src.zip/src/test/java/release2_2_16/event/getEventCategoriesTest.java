package release2_2_16.event;

import com.fasterxml.jackson.core.JsonProcessingException;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getEventCategoriesTest {

    public String _url = Constants.URL_AC + "/event-categories";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String , Object > map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};

    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
//                {Constants.METHOD_GET},
//                {Constants.METHOD_POST}, Method này có API khác
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
        Request.send_validate(_url,_method, _token, json_input_valid, map_params, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS );
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url,_method, _token, json_input_valid, map_params, Constants.STATUS_CODE_405, null );
    }
}
