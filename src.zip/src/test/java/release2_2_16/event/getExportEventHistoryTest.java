package release2_2_16.event;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TimeHelper;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getExportEventHistoryTest {

    public String _url = Constants.URL_AC + "/events/export-history";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_OFFICE_MANAGER;
    public String json_input_valid = "";
    Map<String , Object > map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};

    @DataProvider(name="methods")
    public Object[][] methodsDP(){
        return new Object[][] {
//                {Constants.METHOD_GET},
//                {Constants.METHOD_POST}, Method này có API khác
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test
    public void allValid() throws JsonProcessingException {
//        map_params.put("page", 1);
//        map_params.put("limit", 25);
//        map_params.put("isGuest", true);
        map_params.put("companyIds", "bb97c369-2826-4249-8cd2-b08040fc4739&companyIds=bb97c369-2826-4249-8cd2-b08040fc4729");
//        map_params.put("companyIds", "bb97c369-2826-4249-8cd2-b08040fc4739");//vinsmart
//        map_params.put("companyIds", "bb97c369-2826-4249-8cd2-b08040fc4729");//evotek
//        map_params.put("startDate", TimeHelper.timeNow());
//        map_params.put("endDate", TimeHelper.timeLessOneWeek());
        map_params.put("startDate", TimeHelper.timeLessOneWeek());
        map_params.put("endDate", TimeHelper.timeNow());
        Request.send_validate(_url, _method, _token, json_input_valid, map_params, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS );
    }


    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        map_params.put("page", 1);
        map_params.put("limit", 25);
        map_params.put("isGuest", true);
        map_params.put("companyIds", "918672de-df24-498a-9f5a-c63ba830db98&companyIds=bb97c369-2826-4249-8cd2-b08040fc4739");
        map_params.put("startDate", "1634490000000");
        map_params.put("endDate", "1634835599000");
        Response res = Request.send(_url, met, _token
                , json_input_valid, map_params);
        System.out.println("response: "+res);
        res.prettyPrint();
//        JSONObject json_res = new JSONObject(res.asString());
//        String[] keys = {"code","data"};
//        JsonMinh.jsonlackKeys(keys, json_res);
//        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(405);

    }


    @Test
    public void lowRoleAuthen() throws JsonProcessingException {
        map_params.put("startDate", TimeHelper.timeLessOneWeek());
        map_params.put("endDate", TimeHelper.timeNow());
        Request.send_validate(_url,_method, Constants.TOKEN_OFFICE_MANAGER, json_input_valid, map_params, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS );
    }

}
