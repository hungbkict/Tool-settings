package release2_2_16.appbeusers;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getUserInfoTest {
//public class getCardDetailTest extends BeforeTest {
    //https://uat-technopark.vsmart.net/tnp/app-be/api/v0/swagger-ui.html#/Users%20Resources/getElevatorInfoByUsingGET
    public String _url = Constants.URL_APP_BE + "/user/000669/info";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_PROD_HUNGNK;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @Test
    public void allValid(){
        _url = "https://technopark.vsmart.net/tnp/app-be/api/v0"+ "/user/000669/info";
        Response res= Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
//        Request.send_validate(_url, _method, _token
//                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void lowRoleAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }

    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_405, null);
    }
}
