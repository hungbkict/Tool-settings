package production.door;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class getListDoorsTest {
    public String _url = Constants.URL_PROD_AC + "/doors";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_PROD_HUNGNK;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @Test
    @Description("All variables valid")
    public void doorListDevices() throws JSONException {
        map_params.put("page",1);
        map_params.put("limit",100);
//        map_params.put("orgUnitIds","dbe3c563-0509-49bb-a714-0cf41a45cd7f");
        Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
//         res.prettyPrint();
        JSONObject res_all = new JSONObject(res.asString());
        JSONObject data_all = (JSONObject) res_all.getJSONObject("data");
        JSONArray res_data= data_all.getJSONArray("rows");

        for (int i = 0; i < res_data.length(); i++) {
            JSONObject data = (JSONObject) res_data.get(i);
            List<String> dv_list = new ArrayList<>();
//            String dv_list = "";
            JSONArray dv_arr = data.getJSONArray("devices");
            for (int j = 0; j < dv_arr.length() ; j++) {
                JSONObject dv_data = (JSONObject) dv_arr.get(j);
                dv_list.add(dv_data.getString("name"));
            }
            String name = data. isNull("name") ? "" : data.getString("name");
            System.out.println("(Door) "+name+" have "+ String.join(", ", dv_list));
        }

    }
}
