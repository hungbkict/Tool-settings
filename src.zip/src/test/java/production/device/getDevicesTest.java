package production.device;

import com.jayway.jsonpath.JsonPath;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.LogsHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class getDevicesTest {

    public static String _url = Constants.URL_PROD_AC + "/devices";
    public static String _method = Constants.METHOD_GET;
    public static String _token = Constants.TOKEN_PROD_HUNGNK;
    public static String body_json = "";
    public static Map<String, Object> query_params = new HashMap<>();

    // To automation report purpose
    public String __module = "ACCESS_CONTROL";
    public String __resource = "Device Resource";
    public String __path = "/devices";
    public String __description = "Get list device";


    @Test
    public void allValid() throws IOException {
        query_params.put("limit",100);
        for (int page = 1; page < 3; page++) {

            query_params.put("page",page);
            Response res = Request.send(_url, _method, _token, body_json, query_params);
//            LogsHelper.console(this.getClass().getName(), _method, res);

//            String json_arr = JsonPath.parse(res.asString()).read("$.data.rows").toString();
//            LogsHelper.print_keys(json_arr, "id", "deviceState");
            JSONObject res_all = new JSONObject(res.asString());
            JSONObject data_all = (JSONObject) res_all.getJSONObject("data");
            JSONArray res_data= data_all.getJSONArray("rows");

            for (int i = 0; i < res_data.length(); i++) {
                JSONObject data = (JSONObject) res_data.get(i);
                String id = data.getString("id");
                String code = data.getString("code");
                String deviceType = data. isNull("deviceType") ? "" : data.getString("deviceType");
                String deviceState = data.getString("deviceState");
                JSONObject networkConfig = (JSONObject) data.getJSONObject("networkConfiguration");
                String ipAddress = networkConfig. isNull("ipAddress") ? "" : networkConfig.getString("ipAddress");
                String txt = id+","+ ipAddress+","+deviceState;
//                String txt = id+" , "+ code+" , "+ deviceType+" , "+ ipAddress+" , "+deviceState;
                System.out.println(txt);
                LogsHelper.write_to_file(this.getClass().getName(), "txt", txt+"\n", true);
            }
        }
////hook1
    }

}
