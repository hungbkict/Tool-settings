package production.device;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.LogsHelper;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class getDevicesDataByDeviceIdTest {

    public static String _url = Constants.URL_PROD_AC + "/devices/deviceId/data"; //TODO need change variable
    public static String _method = Constants.METHOD_GET;
    public static String _token = Constants.TOKEN_PROD_HUNGNK;
    public static String body_json = "";
    public static Map<String, Object> query_params = new HashMap<>();

    // To automation report purpose
    public String __module = "ACCESS_CONTROL";
    public String __resource = "Device Resource";
    public String __path = "/devices/deviceId/data"; //TODO need change variable
    public String __description = "Get device data";
    private final String tokenProdHungnk = Constants.TOKEN_PROD_HUNGNK;


    @Test
    public void allValid() throws IOException {
        _url = Constants.URL_PROD_AC + "/devices/283ffd12-2fc4-4a68-80bc-c0b7b7c76dc2/data";
        Response res = Request.send(_url, _method, _token, body_json, query_params);
        LogsHelper.console(this.getClass().getName(), _method, res);
//        Assert.assertEquals("", "");

//hook1
    }


    @Test
    public void allDevices() throws IOException {
        String[] all_dvs = new String[] {
                "34d137a3-aa6f-4468-9101-d9f8f1ddc84c",//CONNECTED
                "8723a1fd-4db6-469f-8bc3-c287355534e7",//CONNECTED
                "9afbef28-ef64-4ed2-ab58-740843dbce72",//CONNECTED
                "bca6f373-bc96-459f-a745-9f4bdbfe9e89",//DISCONNECTED
                "379a531d-b5e7-4c83-894c-96fecd3386d8",//DISCONNECTED
                "ede49ce5-6321-402c-b404-019a0f60f618",//CONNECTED
                "f183253b-6f8b-4b50-a02c-d31ebe833aee",//CONNECTED
                "42a84561-4e7a-49d1-888c-283cdad1f10c",//CONNECTED
                "58824a09-1b0a-4352-9876-2c19fb93577c",//CONNECTED
                "2497ba05-643d-4838-807a-dead243e71ec",//CONNECTED
                "6b78dd89-cf05-45d9-ac66-cbf902dc831e",//CONNECTED
                "f0302351-2827-4677-a056-d968fa35914e",//CONNECTED
                "a00a5b20-74ef-4002-b607-cf139ddc34c6",//CONNECTED
                "de9a27f6-f308-48c9-bf0f-d0404f7c1e65",//CONNECTED
                "089d11fb-1123-4001-8ee2-3eda98956e1f",//CONNECTED
                "634c38dc-0c69-439f-a4ad-ed46347ab4a4",//CONNECTED
                "9c139e9a-1201-455a-9091-4ebd7d866d45",//CONNECTED
                "4af09783-f013-4886-a358-34eb24f458a8",//CONNECTED
                "9b40078d-71ec-4544-af74-097a41883ea2",//CONNECTED
                "2c50eaef-54b5-402e-a88a-24a93dc48b15",//CONNECTED
                "e39f51a2-7f9e-4da6-8cd1-212faf00b706",//CONNECTED
                "c6fe2377-c17b-42f3-b7d9-f55f569bd7e7",//CONNECTED
                "4b8a02e6-18a2-4ef3-b88c-8b21cb7214c8",//CONNECTED
                "283ffd12-2fc4-4a68-80bc-c0b7b7c76dc2",//CONNECTED
                "b00dc46d-e33f-4709-b276-1e70205d5af8",//CONNECTED
                "f66959a1-3324-4d14-80bc-0a8893c155f9",//CONNECTED
                "939294c2-8228-44eb-bff6-e7916c0a8555",//CONNECTED
                "bab21a54-7d84-4a0f-95e6-b365c527c97a",//CONNECTED
                "16db870d-fd7e-49c3-bae7-30b449181a31",//CONNECTED
                "4cb7a3a7-889e-4bb3-b4fb-ecdb06d116fb",//CONNECTED
                "3b0616f4-1c68-42bd-8f35-6ede9cbbccb9",//CONNECTED
                "f72cda65-303c-4e0e-884a-b99e5e6f0d22",//CONNECTED
                "9bbd182c-d31e-4de9-b52d-7a82764ef742",//CONNECTED
                "8461020e-947d-45a6-8c9e-e17ace1ae6e8",//CONNECTED
                "f5aa1cb1-1c20-4432-bf60-9e5f4310e825",//CONNECTED
                "197925d7-276a-4cec-b078-22ce2917e732",//CONNECTED
                "8f769854-bb18-47f5-a788-acc5d35c8298",//CONNECTED
                "131b9623-8c77-4f7e-928a-47ed7f57174f",//CONNECTED
                "c60e3e2f-fac8-4da9-a2aa-11b71cd87545",//CONNECTED
                "7f326752-3918-48a9-b9e8-553da25ced21",//CONNECTED
                "8b932b3b-1137-4049-a044-c50d2d780c72",//CONNECTED
                "9de9e0b3-d0ea-4184-b225-a91eee20117b",//CONNECTED
                "200bf684-ed06-49be-ad2d-05015f4832bb",//CONNECTED
                "de85fe1b-a7d0-43be-bd92-f8a5fd4bc7ae",//CONNECTED
                "b5a3dae3-426b-4388-af5c-3485c8f7ed17",//CONNECTED
                "c8f5ea4a-15e4-443b-8846-b2a57e89fb7f",//CONNECTED
                "6d9de968-a754-4d32-b6a4-e6bf97b023dc",//CONNECTED
                "32a861f1-083c-42ed-b0a6-89480fb8a7b9",//CONNECTED
                "24e35893-b2fe-43fd-905e-ff5da29c0bfe",//DISCONNECTED
                "351a93cb-5842-441f-90f8-8aa0bcdc302a",//CONNECTED
                "bb7c2193-3599-4efe-9a74-fba10b73dc2e",//DISCONNECTED
                "a1157faf-c233-44e3-aa84-22f10fb08e65",//DISCONNECTED
                "bbe1c36f-2dab-41f2-ac97-65d671dd502c",//CONNECTED
                "cd109852-324e-4e8e-a7a5-5aae2dcce3b1",//DISCONNECTED
                "0cd35c52-8c0c-41e0-b39f-485764835888",//CONNECTED
                "405d7e67-4659-46bd-a99f-280168761d1c",//CONNECTED
                "29c3da55-8b37-4e3e-a53d-05b9ba2f461a",//CONNECTED
                "5ff01064-bb72-40cd-b4c4-f3ed2a33b7c6",//CONNECTED
                "18bfd2f5-c745-45fc-a372-7645e8f5c9ba",//CONNECTED
                "df7b0fc8-2c55-4c75-8627-a082c4597c00",//CONNECTED
                "7851bc35-8ace-4987-8b43-b11173f4c402",//CONNECTED
                "3ea8ca95-d406-4d17-97f2-6f9a3a057610",//CONNECTED
                "42e9b47a-9731-4436-81db-b49e5da390be",//CONNECTED
                "442e4094-2f35-47e1-9092-80a91f4f48ed",//CONNECTED
                "a5f0cc41-299b-4402-9022-075e927c4e3c",//CONNECTED
                "515aa407-6245-4dcb-9032-5e61474979bf",//CONNECTED
                "b154d714-76db-4360-b46f-3e256f5120d3",//CONNECTED
                "ec261b9e-e964-4a60-9fc2-465653bbb2e8",//CONNECTED
                "5460b25d-24e0-4c1c-9816-907bcc4e424e",//CONNECTED
                "d04e401f-0a8a-4761-a801-dc40160dbbb8",//CONNECTED
                "e69d4417-132d-452e-a7b9-c512b8fd7798",//CONNECTED
                "c4f7b93a-f021-4821-a0fe-70aad9d93dc2",//CONNECTED
                "464234ff-ff82-4efa-af7d-40b266d4dfbf",//DISCONNECTED
                "62044deb-b4ed-4846-9297-87e1796420f1",//DISCONNECTED
                "b92021db-3c80-45b2-94a5-841d9d23b64a",//DISCONNECTED
                "c863fdd5-3f62-4e8c-bbf0-d17603cd2de0",//CONNECTED
                "404199c6-904b-453f-b2f4-9f3d8e6bab85",//CONNECTED
                "11a92800-14df-4dec-a213-28a40583bcb3",//DISCONNECTED
                "9c84ae71-44b8-4cf7-ae34-b8dcb12a4cc4",//CONNECTED
                "49fe599a-5655-4ca3-beaf-73dc31184f6a",//CONNECTED
                "90800fa8-1583-4828-9e2d-8f81fdef68d8",//CONNECTED
                "f8fcf274-f0d4-4315-b034-8b441a927c8f",//DISCONNECTED
                "c2330b45-1042-4599-b339-49cd621806d0",//DISCONNECTED
                "22819f84-17bc-4937-881b-7d474abfdfbb",//DISCONNECTED
                "80044776-1797-4da6-82fd-8f6543eb7ac5",//DISCONNECTED
                "3591c6e0-6c97-4a7b-b700-3e4fe393eab0",//DISCONNECTED
                "813fd057-5cfd-41c1-a160-410fb935df82",//CONNECTED
                "63041e42-3c6d-4ec8-95b9-5a370e9c7859",//CONNECTED
                "334a6339-45ef-40a1-a9bc-05126e1eb604",//CONNECTED
                "e825a3d7-a5d6-4c41-992e-195895f962f7",//CONNECTED
                "6dbfee5d-9c97-4338-b535-86753f30abb2",//CONNECTED
                "255f6d9b-7267-42cc-a6ff-b5ed954644f0",//CONNECTED
                "78fffc4a-b7cb-4745-961d-ecf99401927b",//DISCONNECTED
                "7a173a8d-3082-4b38-83df-2a1ba78503e2",//CONNECTED
                "4bd0b781-bebb-457c-b242-c9e91df5a68b",//CONNECTED
                "6ce6575f-e2cb-4b51-925e-c5e1671aa2bf",//CONNECTED
                "746c446f-7336-4e27-a7c9-b70ba0e51dc8",//CONNECTED
                "56bf06be-4696-44bd-888f-5d78879d8e09",//CONNECTED
                "7461f7c1-bf5e-4d1a-8b0e-86d03b483e9a",//CONNECTED
                "ba46a024-e851-4781-96e0-72542b147b87",//CONNECTED
                "1fdab7a0-88ca-4fc3-87d5-c1ae8dba3057",//CONNECTED
                "a8b352c1-3e68-4329-8caa-5f1f5895411d",//CONNECTED
                "cac2a340-be62-4f12-917c-53da8a52b12b",//CONNECTED
                "99156c1a-3adc-41f5-addb-7c398881f0b7",//CONNECTED
                "17e03afc-9ec9-413d-9e6d-a4b33bc1c3d2",//CONNECTED
                "0919c822-8817-44e4-b678-e91267049776",//CONNECTED
                "42428f27-556e-4e5b-a68b-5872773ea761",//CONNECTED
                "001dff76-7ea6-4577-bc84-ac159ba332dd",//DISCONNECTED
                "ef524395-aac1-4a3a-92e9-1c4e8985c361",//DISCONNECTED
                "118eda27-6730-4a36-a4d4-2ce6f03be451",//DISCONNECTED
                "d2092f9d-ee20-42d7-9dcd-75c875e965fd",//DISCONNECTED
                "8365c716-9fa4-41ea-8c5c-74f0c005e993",//DISCONNECTED
                "af16781d-dfd7-411e-9d38-dd8808d14081",//DISCONNECTED
                "9897999a-5f16-45bc-aa78-a8939dbae284",//DISCONNECTED
                "8f8d30fc-5496-4c2d-b3e4-9853746c391f",//DISCONNECTED
                "1ff1d665-45d2-449e-9180-f3fa8097fa35",//DISCONNECTED
                "5b5b9994-3a5b-49a7-b812-b1f630db62f1",//DISCONNECTED
                "d874726c-d0e5-4bf3-8cb2-115afbc750b7",//DISCONNECTED
                "393ea857-e91e-41ff-bdce-a43aa3e66b5f",//DISCONNECTED
                "1c65cea1-1685-43b3-85c2-6752a8ec8d46",//DISCONNECTED
                "0ad84e80-cc69-4898-8afd-6d9999f0a379",//DISCONNECTED
                "95d35ceb-64cb-46b1-95cd-bff921b5bfa4",//DISCONNECTED
                "35b9fc14-c5ca-48cf-a7b7-aed59a26a66d",//DISCONNECTED
                "b78c15a3-5fae-48a0-824b-a4e13269d59a",//DISCONNECTED
                "3e78c6af-f238-4b91-b734-f92d0ae38391",//DISCONNECTED
                "cfa17765-af6f-4269-abaa-bc1667d41cdc",//DISCONNECTED
                "bd5dba28-7ee3-488d-9411-b049b05f16f3",//DISCONNECTED
                "03994501-7f3d-4cb5-b2df-2f59ad06de66",//DISCONNECTED
                "83fa0cb7-d6ad-4dc5-9d41-5c6f01fdc345",//DISCONNECTED
                "16cf0e06-e5f4-4a97-b448-89f19925889a",//DISCONNECTED
                "1e24cd99-847e-4be7-b736-1d14d2b63c94",//DISCONNECTED
                "eef53ce7-329c-4fcb-a97a-dcc4f016a0ad",//DISCONNECTED
                "fec2121a-e866-48fd-82d5-faa7de201b0e",//DISCONNECTED
                "c5209fa2-62e2-4015-ba2b-04d90ccd1867",//DISCONNECTED
                "5307d182-1c69-4623-8e07-7ba70399ca67",//DISCONNECTED
                "9acd9eac-7db9-4926-a3e5-293524619353",//DISCONNECTED
                "777fe5be-9790-411d-ad71-85add3cfc017",//DISCONNECTED
                "4e975b42-a27c-4924-8d50-e9f149e0375b",//DISCONNECTED
                "20d4ea8b-8e76-4f10-bf0f-42c150b7e925",//DISCONNECTED
                "03f09401-1fec-47a6-af34-9864f526a05b",//DISCONNECTED
                "92fcb163-fddd-45cf-aef3-99698c6e86cf",//DISCONNECTED
                "66a54891-aa52-45bf-9e5a-1518c7dbd817",//DISCONNECTED
                "7ddc1713-48f1-4073-9da5-c2f19f18d7f4",//DISCONNECTED
                "0fe3388f-5704-44a1-9ee4-ec78c13641a1",//DISCONNECTED
                "bf9c29e9-a284-46cf-a0e7-aafc0ee698d7",//DISCONNECTED

//                "78fffc4a-b7cb-4745-961d-ecf99401927b",//172.22.126.62
//                "24e35893-b2fe-43fd-905e-ff5da29c0bfe",//172.22.126.63
//                "464234ff-ff82-4efa-af7d-40b266d4dfbf",//172.22.126.64
//                "62044deb-b4ed-4846-9297-87e1796420f1",//172.22.126.65
//                "b92021db-3c80-45b2-94a5-841d9d23b64a",//172.22.126.66
//                "bb7c2193-3599-4efe-9a74-fba10b73dc2e",//172.22.126.67
//                "11a92800-14df-4dec-a213-28a40583bcb3",//172.22.126.68
//                "a1157faf-c233-44e3-aa84-22f10fb08e65",//172.22.126.69
//                "bca6f373-bc96-459f-a745-9f4bdbfe9e89",//172.22.126.70
//                "f8fcf274-f0d4-4315-b034-8b441a927c8f",//172.22.126.71
//                "c2330b45-1042-4599-b339-49cd621806d0",//172.22.126.72
//                "22819f84-17bc-4937-881b-7d474abfdfbb",//172.22.126.73
//                "80044776-1797-4da6-82fd-8f6543eb7ac5",//172.22.126.74
//                "cd109852-324e-4e8e-a7a5-5aae2dcce3b1",//172.22.126.75
//                "379a531d-b5e7-4c83-894c-96fecd3386d8",//172.22.126.76
//                "3591c6e0-6c97-4a7b-b700-3e4fe393eab0",//172.22.126.77
//                "bbe1c36f-2dab-41f2-ac97-65d671dd502c",//172.22.126.83
//                "f183253b-6f8b-4b50-a02c-d31ebe833aee",//172.22.126.86
//                "3b0616f4-1c68-42bd-8f35-6ede9cbbccb9",//172.22.126.104
//                "939294c2-8228-44eb-bff6-e7916c0a8555",//172.22.126.108
        };
        String ip="";
        String totalUser="";
        String totalFace="";
        String totalFingerprint="";
        String totalCard="";
        for (String dv_id: all_dvs) {
            _url = Constants.URL_PROD_AC + "/devices/"+dv_id+"/data";
            Response res = Request.send(_url, _method, _token, body_json, query_params);
            JSONObject res_all = new JSONObject(res.asString());
            JSONObject data = (JSONObject) res_all.getJSONObject("data");
            ip = data. isNull("ip") ? "" : data.getString("ip");
            totalUser = data. isNull("totalUser") ? "" : data.getInt("totalUser")+"";
            totalFace = data. isNull("totalFace") ? "" : data.getInt("totalFace")+"";
            totalFingerprint = data. isNull("totalFingerprint") ? "" : data.getInt("totalFingerprint")+"";
            totalCard = data. isNull("totalCard") ? "" : data.getInt("totalCard")+"";
            String txt =dv_id+","+ ip + "," + totalUser + "," + totalFace + "," + totalFingerprint + "," + totalCard;
            System.out.println(txt);
            LogsHelper.write_to_file(this.getClass().getName(), "txt", txt+"\n", true);
        }
    }
    
    
    
}
