package snippets;

import libraries.Constants;
import libraries.Request;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class SendRequest {
    public String _url = Constants.URL_AC + "/cards/download-card";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();

    @Test
    public void default_res_keys() {
        Request.send_validate(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, Constants.DEFAULT_RESPONSE_KEYS);
    }


    @Test
    public void custom_res_key() {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF
                , json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_200, new String[]{"code", "message", "error"});
    }


    @BeforeMethod
    public void init() {
        map_params.put("format", "EXCEL");
        map_params.put("startTime", "1633798800000");
        map_params.put("endTime", "1733798800000");
        map_params.put("downloadMode", "TOTAL");
    }
}
