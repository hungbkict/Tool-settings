package snippets;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

public class DataProvider {

    @org.testng.annotations.DataProvider(name="ac_code")
    public Object[][] acCodes(){
        return new Object[][] {
                {"00152"},
                {"   001521   "},
                {"-100"},
                {"-âvvad"},
                {""}
        };
    }


    @Test(dataProvider = "ac_code")
    public void getInvalidAcCOde(String code) {
        String urlx = Constants.URL_AC + "/users/access-code/" + code;
        Response res = Request.send(urlx, Constants.METHOD_GET, Constants.TOKEN_OFFICE_MANAGER
                , "", Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code", "data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }
}
