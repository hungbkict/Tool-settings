package general.iam.oauth2;

import libraries.Prepare;
import org.testng.annotations.Test;

public class AuthenTest{
    @Test(enabled=true)
    public void getToken() {
        String utoken = Prepare.getTokenCognito();
        System.out.println("Token ADMIN: " + utoken);

//        String uldaptoken = Prepare.getTokenLDAP();
//        System.out.println("User uldaptoken: " + uldaptoken);

//        String u3stoken =Prepare.getTokenVin3S("qa.hungnk2@gmail.com", "vinhkien1A@");
//        System.out.println("User u3stoken: "+u3stoken);

//        String stoken = Prepare.getSchindlerToken();
//        System.out.println("Schindler token: "+stoken);
//
//        String actoken = Prepare.getAcToken();
//        System.out.println("AccessControl token: "+actoken);
    }
}
