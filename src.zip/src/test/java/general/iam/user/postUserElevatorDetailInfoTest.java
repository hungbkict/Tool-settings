package general.iam.user;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

public class postUserElevatorDetailInfoTest {

    public String _url = Constants.URL_IAM + "/users/bf_release2_2_0.elevator-detail-info";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "[\n" +
            "  \"000318\"\n" +
            "]";
    @Test
    public void allValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }
}