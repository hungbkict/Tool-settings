package general.iam.user;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

public class postUserDetailInfoTest {
    public String _url = Constants.URL_IAM + "/users/detail-info";
    public String _method = Constants.METHOD_POST;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "{\n" +
            "  \"orgIds\": [\n" +
            "    \"b76646b6-2dad-4cc9-84c2-17a6380b52df\"\n" +
            "  ],\n" +
            "  \"userIds\": [\n" +
            "    \"54575300-712f-4681-a129-176a485c5a3d\"\n" +
            "  ]\n" +
            "}";
    @Test
    public void allValid() throws JsonProcessingException {
        Response res = Request.send(_url, _method, _token
                , json_input_valid, Constants.MAP_PARAMS_NULL);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }
}
