package general.iam.orgunit;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getListMyCompanyTest {
    //TODO ask Ba about this issue why my company list all companies
    public String _url = Constants.URL_IAM + String.format("/me/companies");
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    Map<String, Object> map_params = new HashMap<>();
    @Test(enabled=true)
    public void getListMyCompanyValid() {
        Response res = Request.send(_url, _method, _token
                , "", map_params);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

}

