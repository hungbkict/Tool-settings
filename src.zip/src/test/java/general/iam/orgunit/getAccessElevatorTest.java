package general.iam.orgunit;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.JsonMinh;
import libraries.Request;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getAccessElevatorTest {
    public String orgUnitID = "e4395865-1fc1-4358-87d8-c83a70c56742";
    public String _url = Constants.URL_IAM + String.format("/org-units/get-access-bf_release2_2_0.elevator");
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    Map<String, Object> map_params = new HashMap<>();
    @Test(enabled=true)
    public void getSyncPagingDataValid() {
        map_params.put("orgUnitId", orgUnitID);
        Response res = Request.send(_url, _method, _token
                , "", map_params);
        res.prettyPrint();
        JSONObject json_res = new JSONObject(res.asString());
        String[] keys = {"code","data"};
        JsonMinh.jsonlackKeys(keys, json_res);
        Assert.assertTrue(JsonMinh.jsonHaveKeys(keys, json_res));
        res.then().statusCode(200);
    }

}
