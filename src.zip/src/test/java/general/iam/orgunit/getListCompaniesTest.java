package general.iam.orgunit;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class getListCompaniesTest {

    public String _url = Constants.URL_IAM + "/companies";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_SYS_MANAGEMENT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @Test(priority = 1)
    @Severity(SeverityLevel.CRITICAL)
    @Description("All variables valid")
    public void allValid(){

         Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
//         res.prettyPrint();
        JSONObject res_all = new JSONObject(res.asString());
        JSONArray res_data= res_all.getJSONArray("data");

        for (int i = 0; i < res_data.length(); i++) {
//            System.out.println(res_data.get(i).toString());
            JSONObject data = (JSONObject) res_data.get(i);

//            System.out.println(data.toString());
            System.out.println("\""+data.getString("orgUnitId")+"\",//"+data.getString("orgUnitName"));
        }

    }

}
