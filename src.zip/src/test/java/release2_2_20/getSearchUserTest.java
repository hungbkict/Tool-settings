package release2_2_20;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.LogsHelper;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class getSearchUserTest {

    public String _url = Constants.URL_PROD_IAM + "/users/search";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_PROD;
    public String json_input_valid = "";
    Map<String , Object > map_params = new HashMap<>();
//{METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_PATCH,METHOD_DELETE};

    @Test
    public void searchPage1() throws IOException {
        for (int i = 1; i < 28; i++) {

            map_params.put("page", 6);
            map_params.put("limit", 100);
            map_params.put("orgUnitIds", "bb97c369-2826-4249-8cd2-b08040fc4739");
            Response res = Request.send(_url, _method, _token
                    , json_input_valid, map_params);
//            res.prettyPrint();
            LogsHelper.write_to_file(this.getClass().getName() + "_all_page", res.asString(), true);
        }
    }

    @Test
    public void searchPage23() throws IOException {
        map_params.put("page", 23);
        map_params.put("limit", 25);
        map_params.put("orgUnitIds", "bb97c369-2826-4249-8cd2-b08040fc4739");
        Response res = Request.send(_url, _method, _token
                , json_input_valid, map_params);
        res.prettyPrint();
        LogsHelper.write_to_file(this.getClass().getName()+"_page23", res.asString());
    }

}
