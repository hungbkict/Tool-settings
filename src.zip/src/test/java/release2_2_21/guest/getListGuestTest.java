package release2_2_21.guest;

import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.LogsHelper;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class getListGuestTest {

    public String _url = Constants.URL_GUEST_REGISTRATION + "/guests";
    public String _method = Constants.METHOD_GET;
    public String _token = Constants.TOKEN_ROOT;
    public String json_input_valid = "";
    Map<String, Object> map_params = new HashMap<>();


    @Test
    public void allValid() throws IOException {
        Response res = Request.send(_url, _method, _token, json_input_valid, map_params);
        LogsHelper.console(this.getClass().getName(), _method, res);
    }


    @Test
    public void lowRoleAuthen() {
        Request.send_validate(_url, _method, Constants.TOKEN_STAFF,
                json_input_valid, map_params, Constants.STATUS_CODE_401, null);
    }

    @DataProvider(name = "methods")  //TODO choose invalid methods only
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PUT},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void getInvalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, null);
    }

    @Test
    public void validateQuerieExpireTime() {
        map_params.put("expireTime", "expireTime");
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieIdentityNumber() {
        map_params.put("identityNumber", "identityNumber");
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieKeyword() {
        map_params.put("keyword", "keyword");
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieLimit() {
        map_params.put("limit", 50);
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQueriePage() {
        map_params.put("page", 1);
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }

    @Test
    public void validateQuerieSort() {
        map_params.put("sort", "sort"); //TODO Change
        Request.send_validate(_url, _method, _token, json_input_valid, map_params,
                Constants.STATUS_CODE_200, new String[]{"code", "data"});
    }
}
