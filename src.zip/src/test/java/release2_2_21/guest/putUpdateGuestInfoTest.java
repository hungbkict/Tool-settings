package release2_2_21.guest;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import libraries.Constants;
import libraries.Request;
import libraries.helper.TextHelper;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import libraries.helper.LogsHelper;
import java.util.HashMap;
import java.util.Map;
import java.io.IOException;
public class putUpdateGuestInfoTest {

    public String _url = Constants.URL_GUEST + "/guests/75daa836-a602-46ae-8cb8-449fbe14bfc9/update";
    public String _method = Constants.METHOD_PUT;
    public String _token = Constants.TOKEN_ADMIN;
    public String json_input_valid = "{\n"+
            "  \"fullName\": \""+ TextHelper.randomName() +" Test\",\n"+
            "  \"gender\": \"MALE\",\n"+
            "  \"identityNumber\": \"32321as1\",\n"+
            "  \"phoneNumber\": \"05165454\"\n"+
            "}";
    Map<String, Object> map_params = new HashMap<>();


    @Test
    public void existedIdentityNumber() throws IOException {
        String guest_id = postGuestRegistrationTest.newGuest();
        _url = Constants.URL_GUEST + "/guests/"+guest_id+"/update";
        String phoneNumber = TextHelper.randomPhoneNumber();
        String existed_id = "00111222";
        json_input_valid = "{\n"+
                "  \"fullName\": \""+ TextHelper.randomName() +" Test\",\n"+
                "  \"gender\": \"MALE\",\n"+
                "  \"isUpdateIdentity\": false,\n"+
                "  \"identityNumber\": \""+existed_id+"\",\n"+
                "  \"phoneNumber\": \""+phoneNumber+"\"\n"+
                "}";
        Response res = Request.send(_url, _method, _token, json_input_valid, map_params);
        LogsHelper.console(res);
    }




    @Test
    public void nochangeIdentityNumber() throws IOException {
        String guest_id = "0ddd0444-368e-464e-9433-8edc32408dc1";
        _url = Constants.URL_GUEST + "/guests/"+guest_id+"/update";
        String phoneNumber = TextHelper.randomPhoneNumber();
        String existed_id = "45645147143424";
        json_input_valid = "{\n"+
                "  \"fullName\": \""+ TextHelper.randomName() +" Test1\",\n"+
                "  \"gender\": \"MALE\",\n"+
                "  \"isUpdateIdentity\": false,\n"+
                "  \"identityNumber\": \""+existed_id+"\",\n"+
                "  \"phoneNumber\": \""+phoneNumber+"\"\n"+
                "}";
        Response res = Request.send(_url, _method, _token, json_input_valid, map_params);
        LogsHelper.console(res);
        Assert.assertEquals(existed_id, res.jsonPath().get("data.identityNumber"));
    }

    @Test
    public void changeIdentityNumber() throws IOException {
        String guest_id = "0e9426ba-9f40-4668-aa0f-cef20ac364f9";
        _url = Constants.URL_GUEST + "/guests/"+guest_id+"/update";
        String phoneNumber = TextHelper.randomPhoneNumber();
//        for (int i = 0; i < 10; i++) {

            String not_existed_id = "4564514714"+TextHelper.randomInt(1111,9999);
//        String not_existed_id = "";

            json_input_valid = "{\n"+
                    "  \"fullName\": \"Mang An Test\",\n"+
//                "  \"fullName\": \""+ TextHelper.randomName() +" Test\",\n"+
                    "  \"gender\": \"MALE\",\n"+
                    "  \"isUpdateIdentity\": true,\n"+
                    "  \"identityNumber\": \""+not_existed_id+"\",\n"+
                    "  \"phoneNumber\": \""+phoneNumber+"\"\n"+
                    "}";
            Response res = Request.send(_url, _method, _token, json_input_valid, map_params);
            LogsHelper.console(res);
//        }
    }



    @Test
    public void changePhoneNumber() throws IOException {
        String guest_id = "0ddd0444-368e-464e-9433-8edc32408dc1";
        _url = Constants.URL_GUEST + "/guests/"+guest_id+"/update";
        String phoneNumber = TextHelper.randomPhoneNumber();

        json_input_valid = "{\n"+
                "  \"fullName\": \"Mang An Test\",\n"+
//                "  \"fullName\": \""+ TextHelper.randomName() +" Test\",\n"+
                "  \"gender\": \"MALE\",\n"+
                "  \"isUpdateIdentity\": false,\n"+
                "  \"identityNumber\": \"45645147143424\",\n"+
                "  \"phoneNumber\": \""+phoneNumber+"\"\n"+
                "}";
        Response res = Request.send(_url, _method, _token, json_input_valid, map_params);
        LogsHelper.console(res);
        Assert.assertEquals(phoneNumber, res.jsonPath().get("data.phoneNumber"));
    }

    @Test
    public void changeName() throws IOException {
        String guest_id = "0ddd0444-368e-464e-9433-8edc32408dc1";
        _url = Constants.URL_GUEST + "/guests/"+guest_id+"/update";
        String phoneNumber = TextHelper.randomPhoneNumber();
        String name = TextHelper.randomName();

        json_input_valid = "{\n"+
                "  \"fullName\": \""+ name +"\",\n"+
//                "  \"fullName\": \""+ TextHelper.randomName() +" Test\",\n"+
                "  \"gender\": \"MALE\",\n"+
                "  \"isUpdateIdentity\": false,\n"+
                "  \"identityNumber\": \"45645147143424\",\n"+
                "  \"phoneNumber\": \""+phoneNumber+"\"\n"+
                "}";
        Response res = Request.send(_url, _method, _token, json_input_valid, map_params);
        LogsHelper.console(res);
        Assert.assertEquals(name, res.jsonPath().get("data.fullName"));
    }



    @DataProvider(name = "methods")
    public Object[][] methodsDP() {
        return new Object[][]{
                {Constants.METHOD_GET},
                {Constants.METHOD_POST},
                {Constants.METHOD_PATCH},
                {Constants.METHOD_DELETE},
        };
    }

    @Test(dataProvider = "methods")
    public void invalidMethods(String met) {
        Request.send_validate(_url, met, _token
                , json_input_valid, map_params, Constants.STATUS_CODE_405, null);
    }

    @Test
    public void noAuthen() throws JsonProcessingException {
        Request.send_validate(_url, _method, Constants.TOKEN_EMPTY,
                json_input_valid, Constants.MAP_PARAMS_NULL, Constants.STATUS_CODE_401, null);
    }
}